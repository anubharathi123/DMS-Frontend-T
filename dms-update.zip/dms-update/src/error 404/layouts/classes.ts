// ----------------------------------------------------------------------

export const layoutClasses = {
  root: 'layout__root',
  main: 'layout__main',
  header: 'layout__header',
  content: 'layout__main__content',
  hasSidebar: 'layout__has__sidebar',
};
