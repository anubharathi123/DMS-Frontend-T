import React, { useState, useEffect, useCallback, useMemo } from 'react';
import {
    Box,
    Button,
    Card,
    Table,
    TableBody,
    TableCell,
    TableContainer,
    TableHead,
    TableRow,
    TablePagination,
    Typography,
    InputAdornment,
    IconButton,
    useTheme,
    MenuItem,
    Dialog,
    DialogActions,
    DialogContent,
    DialogTitle,
    Select,
    OutlinedInput,
    Popover,
    TableSortLabel,
    Checkbox,
    FormControl,
    InputLabel
} from '@mui/material';
import SearchIcon from '@mui/icons-material/Search';
import { Filter as FilterIcon, Download, RotateCcw } from 'lucide-react';
import apiServices from '../../ApiServices/ApiServices';
import AddIcon from '@mui/icons-material/Add';
import { useNavigate } from 'react-router-dom';
import styled from '@emotion/styled';
import { DatePicker } from '@mui/x-date-pickers/DatePicker';
import { AdapterDayjs } from '@mui/x-date-pickers/AdapterDayjs';
import { LocalizationProvider } from '@mui/x-date-pickers/LocalizationProvider';
import dayjs from 'dayjs';
import 'dayjs/locale/en';
import CalendarMonthIcon from '@mui/icons-material/CalendarMonth';

const StatusText = styled('span')(({ status }) => ({
    fontWeight: 'bold',
    padding: '4px 8px',
    borderRadius: '4px',
    display: 'inline-block',
    textAlign: 'center',
    minWidth: '80px',
    backgroundColor:
        status === 'REJECTED' ? '#ffebee' :
            status === 'APPROVED' ? '#e8f5e9' :
                '#fff3e0',
    color:
        status === 'REJECTED' ? '#d32f2f' :
            status === 'APPROVED' ? '#2e7d32' :
                '#ffa726',
}));

const headLabel = [
    { id: 'declarationNumber', label: 'Declaration Number', align: 'center', width: '15%' },
    { id: 'fileName', label: 'File Name', align: 'center', width: '20%' },
    { id: 'updatedDate', label: 'Updated Date', align: 'center', width: '15%' },
    { id: 'documentType', label: 'Doc Type', align: 'center', width: '15%' },
    { id: 'status', label: 'Status', align: 'center', width: '10%' },
];

const DocumentList = () => {
    const [data, setData] = useState([]);
    const [searchTerm, setSearchTerm] = useState('');
    const [filter, setFilter] = useState('');
    const [rowsPerPage, setRowsPerPage] = useState(5);
    const [currentPage, setCurrentPage] = useState(0);
    const [isLoading, setIsLoading] = useState(false);
    const [anchorEl, setAnchorEl] = useState(null);
    const theme = useTheme();
    const navigate = useNavigate();
    const url = 'http://localhost:8000';
    const [order, setOrder] = useState('asc');
    const [orderBy, setOrderBy] = useState('declarationNumber');
    const [selected, setSelected] = useState([]);
    const [openPdfDialog, setOpenPdfDialog] = useState(false);
    const [selectedPdfUrl, setSelectedPdfUrl] = useState('');
    const [selectedDate, setSelectedDate] = useState(null);

    const handleCalendarClick = (event) => {
        setAnchorEl(event.currentTarget); // Open the popover
    };
    const handleClose = () => {
        setAnchorEl(null); // Close the popover
    };

    const open = Boolean(anchorEl); // Check if popover is open
    const id = open ? 'date-picker-popover' : undefined;

    useEffect(() => {
        const fetchDocuments = async () => {
            try {
                setIsLoading(true);
                const response = await apiServices.getDocuments();
                const documents = response.map(doc => ({
                    declarationNumber: doc.declaration_number,
                    fileName: doc.current_version?.file_path?.split('/').pop() || '',
                    filePath: doc.current_version?.file_path || '',
                    updatedDate: doc.updated_at,
                    documentType: doc.document_type?.name || '',
                    status: doc.status || '',
                    file: doc.current_version?.file_path || '',
                    id: doc.id
                }));

                setData(documents);
            } catch (error) {
                console.error('Error fetching documents:', error);
            } finally {
                setIsLoading(false);
            }
        };

        fetchDocuments();
    }, []);

    const handleRequestSort = (event, property) => {
        const isAsc = orderBy === property && order === 'asc';
        setOrder(isAsc ? 'desc' : 'asc');
        setOrderBy(property);
    };

    const sortData = (dataToSort, order, orderBy) => {
        return [...dataToSort].sort((a, b) => {
            let comparison = 0;
            if (orderBy === 'declarationNumber') {
                comparison = a.declarationNumber.localeCompare(b.declarationNumber);
            } else if (orderBy === 'fileName') {
                comparison = a.fileName.localeCompare(b.fileName);
            } else if (orderBy === 'updatedDate') {
                comparison = new Date(a.updatedDate).getTime() - new Date(b.updatedDate).getTime();
            } else if (orderBy === 'documentType') {
                comparison = a.documentType.localeCompare(b.documentType);
            } else if (orderBy === 'status') {
                comparison = a.status.localeCompare(b.status);
            }
            return order === 'asc' ? comparison : -comparison;
        });
    };

    const handleDateChange = (date) => {
        const formattedDate = date ? dayjs(date).format('DD-MM-YYYY') : '';
        setSelectedDate(date);
        setSearchTerm(formattedDate.toLowerCase());
        setCurrentPage(0);
        handleClose(); // Close Popover after selecting date
    };

    const filteredData = data.filter((item) => {
        const formattedCreatedDate = dayjs(item.updatedDate).format('DD-MM-YYYY').toLowerCase();
        return (
            (!filter || item.status === filter) &&
            (item.declarationNumber.toLowerCase().includes(searchTerm.toLowerCase()) ||
                item.fileName.toLowerCase().includes(searchTerm.toLowerCase()) ||
                formattedCreatedDate.includes(searchTerm.toLowerCase()) ||
                item.documentType.toLowerCase().includes(searchTerm.toLowerCase()) ||
                item.status.toLowerCase().includes(searchTerm.toLowerCase())
            ));
    });

    const sortDataMemoized = useMemo(() => {
        return sortData(filteredData, order, orderBy);
    }, [filteredData, order, orderBy]);

    const handleChangePage = (event, newPage) => {
        setCurrentPage(newPage);
    };

    const handleChangeRowsPerPage = (event) => {
        setRowsPerPage(parseInt(event.target.value, 10));
        setCurrentPage(0);
    };

    const handleFilterClick = (event) => {
        setAnchorEl(event.currentTarget);
    };

    const handleFilterClose = (value) => {
        setFilter(value);
        setAnchorEl(null);
    };

    const handleAddNewDocument = () => {
        navigate('/upload');
    };

    const handleOpenPdf = (filePath) => {
        if (!filePath) {
            console.error("Invalid PDF file path:", filePath);
            return;
        }

        const fullPdfUrl = filePath.startsWith('http') ? filePath : `${url}/${filePath.replace(/^\/+/, '')}`;
        setSelectedPdfUrl(fullPdfUrl);
        setOpenPdfDialog(true);
    };

    const handleClosePdf = () => {
        setOpenPdfDialog(false);
        setSelectedPdfUrl('');
    };

    const handleDownload = (filePath) => {
        fetch(filePath)
            .then(response => response.blob())
            .then(blob => {
                const url = window.URL.createObjectURL(new Blob([blob]));
                const link = document.createElement('a');
                link.href = url;
                link.setAttribute('download', filePath.split('/').pop());
                document.body.appendChild(link);
                link.click();
                link.remove();
                window.URL.revokeObjectURL(url);
            })
            .catch(error => {
                console.error('Error downloading file:', error);
            });
    };

    const handleReset = () => {
        setSearchTerm('');
        setFilter('');
        setCurrentPage(0);
    };

    const visibleRows = sortDataMemoized.slice(currentPage * rowsPerPage, currentPage * rowsPerPage + rowsPerPage);

    const handleClick = useCallback((id) => {
        setSelected((prevSelected) => {
            if (prevSelected.includes(id)) {
                return prevSelected.filter((selectedId) => selectedId !== id);
            } else {
                return [...prevSelected, id];
            }
        });
    }, [setSelected]);

    const handleSelectAllClick = (event) => {
        if (event.target.checked) {
            const newSelecteds = visibleRows.map((row) => row.id);
            setSelected(newSelecteds);
        } else {
            setSelected([]);
        }
    };

    const isSelected = useCallback((id) => selected.includes(id), [selected]);

    const numSelected = selected.length;
    const rowCount = filteredData.length;

    const createSortHandler = (property) => (event) => {
        handleRequestSort(event, property);
    };

    return (
        <Box sx={{
            marginLeft: {
                xs: "0",
                sm: "0",
                md: "250px",
            },
            marginTop: "100px",
            width: {
                xs: '100%',
                sm: '100%',
                md: 'calc(100% - 250px)',
            },
            transition: 'width 0.3s ease-in-out',
            pr: 3,
            boxSizing: 'border-box'
        }}>
            <Typography variant="h4" gutterBottom sx={{ fontWeight: 'bold', paddingRight: '20px', fontSize: '18px', color: 'darkblue' }}>
                Document List
            </Typography>
            <Box sx={{
                display: 'flex',
                justifyContent: 'flex-end',
                mb: 2,
            }}>
                <Button
                    variant="contained"
                    sx={{
                        backgroundColor: 'black',
                        color: 'white',
                        fontSize: '12px',
                        borderRadius: '1000px',
                        padding: '4px 8px',
                        marginTop: '-40px',
                        '&:hover': {
                            backgroundColor: '#424242',
                        },
                    }}
                    onClick={handleAddNewDocument}
                    startIcon={<AddIcon />}
                >
                    New Document
                </Button>
            </Box>
            <Card sx={{
                width: '100%',
                minWidth: 600,
                p: 2,
                backgroundColor: theme.palette.background.paper,
                boxShadow: '0px 3px 5px rgba(0, 0, 0, 0.1)',
                borderRadius: '8px',
                border: `1px solid ${theme.palette.divider}`,
                background: theme.palette.grey[50],
                mx: 'auto',
                boxSizing: 'border-box'
            }}>
                <Box display="flex" justifyContent="space-between" mb={2}>
                    <OutlinedInput
                        value={searchTerm}
                        onChange={(e) => setSearchTerm(e.target.value)}
                        placeholder="Search..."
                        sx={{
                            maxWidth: 260, fontSize: '14px',
                            '&:hover .MuiOutlinedInput-notchedOutline': {
                                borderColor: theme.palette.primary.main,
                            },
                            background: theme.palette.common.white,
                        }}
                        startAdornment={
                            <InputAdornment position="start">
                                <SearchIcon />
                            </InputAdornment>
                        }
                        endAdornment={
                            <InputAdornment position="end">
                                <IconButton onClick={handleCalendarClick}>
                                    <CalendarMonthIcon />
                                </IconButton>
                            </InputAdornment>
                        }
                    />
                    <FormControl variant="outlined" sx={{ minWidth: 250 }}>
                        <InputLabel id="status-label" sx={{ fontSize: '12px' }}>Status</InputLabel>
                        <Select
                            labelId="status-label"
                            value={filter}
                            onChange={(e) => setFilter(e.target.value)}
                            label="Status"
                            sx={{
                                fontSize: '14px',
                                '& .MuiSelect-select': { textDecoration: 'none' },
                                background: theme.palette.common.white,
                            }}
                        >
                            <MenuItem value="" sx={{ fontSize: '12px' }}>All</MenuItem>
                            <MenuItem value="PENDING" sx={{ fontSize: '12px' }}>Pending</MenuItem>
                            <MenuItem value="REJECTED" sx={{ fontSize: '12px' }}>Rejected</MenuItem>
                            <MenuItem value="APPROVED" sx={{ fontSize: '12px' }}>Approved</MenuItem>
                        </Select>
                    </FormControl>
                </Box>
                <Popover
                    id={id}
                    open={open}
                    anchorEl={anchorEl}
                    onClose={handleClose}
                    anchorOrigin={{
                        vertical: 'bottom',
                        horizontal: 'left',
                    }}
                >
                    <LocalizationProvider dateAdapter={AdapterDayjs} adapterLocale="en">
                        <DatePicker
                            value={selectedDate}
                            onChange={handleDateChange}
                            renderInput={() => { }}
                            format="DD-MM-YYYY"
                        />
                    </LocalizationProvider>
                </Popover>
                <TableContainer sx={{ width: '100%', overflowX: 'auto' }}>
                    <Table size="small" sx={{ width: '100%', minWidth: 650 }}>
                        <TableHead sx={{
                            background: theme.palette.grey[100],
                            borderBottom: `1px solid ${theme.palette.divider}`,
                        }}>
                            <TableRow>
                                <TableCell padding="checkbox">
                                    <Checkbox
                                        indeterminate={numSelected > 0 && numSelected < rowCount}
                                        checked={rowCount > 0 && numSelected === rowCount}
                                        onChange={handleSelectAllClick}
                                        inputProps={{ 'aria-label': 'select all documents' }}
                                        sx={{
                                            color: theme.palette.grey[600],
                                            '&.Mui-checked': {
                                                color: theme.palette.primary.main,
                                            },
                                            '& .MuiSvgIcon-root': {
                                                fontSize: 16,
                                            },
                                        }}
                                    />
                                </TableCell>
                                {headLabel.map((headCell) => (
                                    <TableCell
                                        key={headCell.id}
                                        align={headCell.align}
                                        sortDirection={orderBy === headCell.id ? order : false}
                                    >
                                        <TableSortLabel
                                            active={orderBy === headCell.id}
                                            direction={orderBy === headCell.id ? order : 'asc'}
                                            onClick={createSortHandler(headCell.id)}
                                        >
                                            {headCell.label}
                                        </TableSortLabel>
                                    </TableCell>
                                ))}
                            </TableRow>
                        </TableHead>
                        <TableBody>
                            {visibleRows.map((item, index) => {
                                const isItemSelected = isSelected(item.id);
                                return (
                                    <TableRow
                                        hover
                                        key={index}
                                        role="checkbox"
                                        aria-checked={isItemSelected}
                                        selected={isItemSelected}
                                    >
                                        <TableCell padding="checkbox">
                                            <Checkbox
                                                checked={isItemSelected}
                                                onChange={(event) => handleClick(item.id)}
                                                inputProps={{ 'aria-labelledby': `enhanced-table-checkbox-${index}` }}
                                                sx={{
                                                    '& .MuiSvgIcon-root': {
                                                        fontSize: 16,
                                                    },
                                                }}
                                            />
                                        </TableCell>
                                        <TableCell sx={{ textAlign: 'center' }}>{item.declarationNumber}</TableCell>
                                        <TableCell sx={{ textAlign: 'center' }}>
                                            {item.fileName ? (
                                                <a href={(url + item.file)} target='_blank' rel='noopener noreferrer'>
                                                    {item.fileName.split('/').pop().substring(0, 20) + '...'}
                                                </a>
                                            ) : (
                                                "Null"
                                            )}
                                        </TableCell>
                                        <TableCell sx={{ textAlign: 'center' }}>{new Date(item.updatedDate).toLocaleDateString()}</TableCell>
                                        <TableCell sx={{ textAlign: 'center' }}>{item.documentType}</TableCell>
                                        <TableCell sx={{ textAlign: 'center' }}><StatusText status={item.status}>{item.status}</StatusText></TableCell>
                                    </TableRow>
                                );
                            })}
                        </TableBody>
                    </Table>
                </TableContainer>
                <TablePagination
                    rowsPerPageOptions={[5, 10, 25]}
                    count={filteredData.length}
                    rowsPerPage={rowsPerPage}
                    page={currentPage}
                    onPageChange={handleChangePage}
                    onRowsPerPageChange={handleChangeRowsPerPage}
                    sx={{
                        display: 'flex',
                        justifyContent: 'flex-end',
                        alignItems: 'center',
                        mt: 2,
                        fontSize: '12px',
                        background: theme.palette.common.white,
                        border: 'none',
                    }}
                    labelDisplayedRows={({ from, to, count }) => `${from}-${to} of ${count}`}
                />
            </Card>
            {/* PDF Dialog */}
            <Dialog open={openPdfDialog} onClose={handleClosePdf} maxWidth="md" fullWidth>
                <DialogTitle>PDF Viewer</DialogTitle>
                <DialogContent style={{ height: '60vh' }}>
                    <iframe
                        src={selectedPdfUrl.startsWith('http') ? selectedPdfUrl : `${url}/${selectedPdfUrl.replace(/^\/+/, '')}`}
                        title="PDF Viewer"
                        width="100%"
                        height="100%"
                        style={{ border: 'none' }}
                    />
                </DialogContent>
                <DialogActions>
                    <Button onClick={() => handleDownload(selectedPdfUrl)} startIcon={<Download />}>
                        Download
                    </Button>
                    <Button onClick={handleClosePdf} color="primary">
                        Close
                    </Button>
                </DialogActions>
            </Dialog>
        </Box>
    );
}

export default DocumentList;
