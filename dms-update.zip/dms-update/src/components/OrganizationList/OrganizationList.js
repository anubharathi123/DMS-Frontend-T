/* eslint-disable no-const-assign */
import React, { useState, useEffect, useCallback, useMemo } from 'react';
import {
    Box, Card, Table, Button, TableBody, Typography, TableContainer,
    TablePagination, TableRow, TableCell, TableHead, Select, MenuItem,
    FormControl, InputLabel, TableSortLabel, Tooltip, OutlinedInput, InputAdornment,
    IconButton, Menu, ListItemIcon, ListItemText, useTheme, useMediaQuery, Popover
} from '@mui/material';
import SearchIcon from '@mui/icons-material/Search';
import DeleteIcon from '@mui/icons-material/Delete';
import EditIcon from '@mui/icons-material/Edit';
import MoreVertIcon from '@mui/icons-material/MoreVert';
import AddIcon from '@mui/icons-material/Add';
import apiServices, { API_URL1 } from '../../ApiServices/ApiServices'; // Import FILE_SERVER_URL and API_URL1
import Checkbox from '@mui/material/Checkbox';
import { styled } from '@mui/system';
import { useNavigate } from 'react-router-dom';
import { DatePicker } from '@mui/x-date-pickers/DatePicker';
import { AdapterDayjs } from '@mui/x-date-pickers/AdapterDayjs';
import { LocalizationProvider } from '@mui/x-date-pickers/LocalizationProvider';
import dayjs from 'dayjs';
import 'dayjs/locale/en';
import CalendarMonthIcon from '@mui/icons-material/CalendarMonth';
import { FontAwesomeIcon } from '@fortawesome/react-fontawesome'
import { faToggleOff, faToggleOn } from '@fortawesome/free-solid-svg-icons';
import { faPencil, faTrash } from '@fortawesome/free-solid-svg-icons'; // Import pencil and trash icons
import Loader from "react-js-loader";

const StatusIndicator = styled(Box)(({ status }) => ({
    display: 'inline-block',
    padding: '4px 8px',
    borderRadius: '4px',
    fontSize: '12px',
    fontWeight: 'bold',
    color: 'black',
    backgroundColor: status === 'Active' ? '#A5D6A7' : status === 'Inactive' ? '#F44336' : '#9E9E9E',
}));

const headLabel = [
    { id: 'username', label: 'Username', align: 'left', width: '15%' },
    { id: 'org_name', label: 'Organization', align: 'left', width: '20%' },
    { id: 'msa_doc', label: 'MSA Doc', align: 'left', width: '20%' },
    { id: 'created_date', label: 'Created Date', align: 'left', width: '15%' },
    { id: 'status', label: 'Status', align: 'center', width: '10%' },
    { id: 'actions', label: 'Actions', align: 'center', width: '10%' },
];

const UserTableHead = ({ order, orderBy, onRequestSort, onSelectAllClick, numSelected, rowCount }) => {
    const createSortHandler = (property) => (event) => {
        onRequestSort(event, property);
    };
    const theme = useTheme();
    return (
        <TableHead sx={{
            background: theme.palette.grey[100],
            borderBottom: `1px solid ${theme.palette.divider}`,
        }}>
            <TableRow>
                <TableCell padding="checkbox">
                    <Checkbox
                        indeterminate={numSelected > 0 && numSelected < rowCount}
                        checked={rowCount > 0 && numSelected === rowCount}
                        onChange={onSelectAllClick}
                        inputProps={{ 'aria-label': 'select all users' }}
                        sx={{
                            color: theme.palette.grey[600],
                            '&.Mui-checked': {
                                color: theme.palette.primary.main,
                            },
                            '& .MuiSvgIcon-root': {
                                fontSize: 16,
                            },
                        }}
                    />
                </TableCell>
                {headLabel.map((headCell) => (
                    <TableCell
                        key={headCell.id}
                        align={headCell.align}
                        sx={{
                            fontWeight: '600',
                            padding: '12px 8px',
                            whiteSpace: 'nowrap',
                            width: headCell.width,
                            color: theme.palette.text.primary,
                            fontSize: '14px',
                            '& .MuiTableSortLabel-root': {
                                color: theme.palette.text.primary,
                                '&:hover': {
                                    color: theme.palette.primary.main,
                                },
                                '&.Mui-active': {
                                    color: theme.palette.primary.main,
                                },
                            },
                        }}
                    >
                        <TableSortLabel
                            active={orderBy === headCell.id}
                            direction={orderBy === headCell.id ? order : 'asc'}
                            onClick={createSortHandler(headCell.id)}
                        >
                            {headCell.label}
                        </TableSortLabel>
                    </TableCell>
                ))}
            </TableRow>
        </TableHead>
    );
};

const UserTableRow = ({ row, handleEdit, handleDelete, isSelected, handleClick, handleFreeze, url }) => {  // Add url prop
    const [anchorEl, setAnchorEl] = useState(null);
    const open = Boolean(anchorEl);
    const theme = useTheme();
    const handleMenuClick = (event) => {
        setAnchorEl(event.currentTarget);
    };
    const handleMenuClose = () => {
        setAnchorEl(null);
    };

    const handleFileClick = (fileUrl) => {
        window.open(`${url}/${fileUrl}`, '_blank');
    };
    return (
        <TableRow
            hover
            role="checkbox"
            aria-checked={isSelected}
            selected={isSelected}
            sx={{
                '&:nth-of-type(odd)': {
                    backgroundColor: theme.palette.grey[50],
                },
                '&:hover': {
                    backgroundColor: theme.palette.grey[100],
                },
                '&.Mui-selected': {
                    backgroundColor: theme.palette.grey[200],
                },
            }}
        >
            <TableCell padding="checkbox">
                <Checkbox checked={isSelected} onChange={(event) => handleClick(row.id)}
                    sx={{
                        '& .MuiSvgIcon-root': {
                            fontSize: 16,
                        },
                    }} />
            </TableCell>
            <TableCell sx={{ padding: '8px', whiteSpace: 'nowrap', color: theme.palette.text.primary, fontSize: '12px' }}>{row.username}</TableCell>
            <TableCell sx={{ padding: '8px', whiteSpace: 'nowrap', color: theme.palette.text.primary, fontSize: '12px' }}>
                <Tooltip title={row.org_name} arrow>
                    <span>{row.org_name.length > 20 ? `${row.org_name.substring(0, 20)}...` : row.org_name}</span>
                </Tooltip>
            </TableCell>
            <TableCell sx={{ padding: '8px', whiteSpace: 'nowrap', color: theme.palette.text.primary, fontSize: '12px' }}>
                {row.msa_doc ? (
                    <a
                        href={`${url}/${row.msa_doc}`}
                        target='_blank'
                        rel='noopener noreferrer'
                        style={{ color: theme.palette.primary.main, textDecoration: 'none' }}
                    >
                        {row.msa_doc.split('/').pop()}
                    </a>
                ) : "Null"}
            </TableCell>
            <TableCell sx={{ padding: '8px', whiteSpace: 'nowrap', color: theme.palette.text.primary, fontSize: '12px' }}>{new Date(row.created_date).toLocaleDateString()}</TableCell>
            <TableCell align="center" sx={{ padding: '8px' }}>
                <StatusIndicator status={row.status ? "Inactive" : "Active"}>
                    {row.status ? "Inactive" : "Active"}
                </StatusIndicator>
            </TableCell>
            <TableCell align="center" sx={{ padding: '8px', whiteSpace: 'nowrap' }}>
                <IconButton
                    aria-label="more"
                    id="long-button"
                    aria-controls={open ? 'long-menu' : undefined}
                    aria-expanded={open ? 'true' : undefined}
                    aria-haspopup="true"
                    onClick={handleMenuClick}
                >
                    <MoreVertIcon />
                </IconButton>
                <Menu
                    id="long-menu"
                    MenuListProps={{
                        'aria-labelledby': 'long-button',
                    }}
                    anchorEl={anchorEl}
                    open={open}
                    onClose={handleMenuClose}
                    PaperProps={{
                        style: {
                            width: 'auto',
                            boxShadow: '0px 2px 10px rgba(0, 0, 0, 0.1)',
                        },
                    }}
                >
                    <MenuItem onClick={() => { handleEdit(row.id); handleMenuClose(); }} sx={{ fontSize: '12px', '&:hover': { backgroundColor: theme.palette.grey[100] } }}>
                        <ListItemIcon>
                            <EditIcon style={{ fontSize: '16px' }} />
                        </ListItemIcon>
                        <ListItemText>Edit</ListItemText>
                    </MenuItem>
                    <MenuItem onClick={() => { handleFreeze(row.id, row.status); handleMenuClose(); }} sx={{ fontSize: '12px', '&:hover': { backgroundColor: theme.palette.grey[100] } }}>
                        <ListItemIcon>
                            {row.status ? <FontAwesomeIcon icon={faToggleOff} /> : <FontAwesomeIcon icon={faToggleOn} />}
                        </ListItemIcon>
                        <ListItemText>{row.status ? "Resume" : "Freeze"}</ListItemText>
                    </MenuItem>
                    <MenuItem onClick={() => { handleDelete(row.id); handleMenuClose(); }} sx={{ fontSize: '12px', '&:hover': { backgroundColor: theme.palette.grey[100] } }}>
                        <ListItemIcon>
                            <DeleteIcon style={{ fontSize: '16px' }} />
                        </ListItemIcon>
                        <ListItemText>Delete</ListItemText>
                    </MenuItem>
                </Menu>
            </TableCell>
        </TableRow>
    );
};
const OrganizationList = () => {
    const [data, setData] = useState([]);
    const [searchTerm, setSearchTerm] = useState('');
    const [statusFilter, setStatusFilter] = useState('');
    const [order, setOrder] = useState('asc');
    const [orderBy, setOrderBy] = useState('username');
    const [page, setPage] = useState(0);
    const [rowsPerPage, setRowsPerPage] = useState(5);
    const [selected, setSelected] = useState([]);
    const theme = useTheme();
    const navigate = useNavigate();
    const isSmallScreen = useMediaQuery(theme.breakpoints.down('md'));
    const [anchorEl, setAnchorEl] = useState(null);  // for Popover
    const [selectedDate, setSelectedDate] = useState(null);
    const [isLoading, setIsLoading] = useState(false); // Added loading state
    const url = API_URL1; // Get API_URL1 from ApiServices
    const [deletedOrg, setDeletedOrg] = useState([])

    const handleCalendarClick = (event) => {
        setAnchorEl(event.currentTarget); // Open the popover
    };

    const handleClose = () => {
        setAnchorEl(null); // Close the popover
    };

    const open = Boolean(anchorEl); // Check if popover is open
    const id = open ? 'date-picker-popover' : undefined;

    useEffect(() => {
        const fetchOrganizations = async () => {
            try {
                setIsLoading(true);  // Set loading to true before fetching data
                const response = await apiServices.getOrganizations();
                if (response && response.organization) {
                    const organizations = response.organization.map(org => ({
                        username: org.auth_user.username,
                        org_name: org.company_name,
                        msa_doc: org.contract_doc,
                        created_date: org.created_at,
                        status: org.is_frozen,
                        id: org.id, // Use org.id instead of org.auth_user.id
                        delete:org.is_delete
                    }));
                    setData(organizations);
                } else {
                    console.error("Error: Invalid response format from API");
                }
            } catch (error) {
                console.error("Error fetching organizations:", error);
            } finally {
                setIsLoading(false); // Set loading to false after fetching data
            }
        };

        fetchOrganizations();
    }, [navigate]);

    const handleSearch = (e) => {
        setSearchTerm(e.target.value.toLowerCase());
        setPage(0);
    };

    const handleStatusFilter = (e) => {
        setStatusFilter(e.target.value);
        setPage(0);
    };

    const handleSort = (event, property) => {
        const isAsc = orderBy === property && order === 'asc';
        setOrder(isAsc ? 'desc' : 'asc');
        setOrderBy(property);
    };

    const handleEdit = (id) => {
        navigate(`/CompanyUpdate/${id}`); // Navigate to the edit page with the organization's ID
    };

    const handleDelete = async (id) => {
        if (!window.confirm("Are you sure you want to delete this organization?")) {
            return;
        }

        try {
            setIsLoading(true);

            // Call API to delete the organization
            const response = await apiServices.deleteOrganization(id);

            if (response.error) { // Ensure API returns success
                setData(prevData => prevData.filter(org => org.id !== id));
            }
        } catch (error) {
            console.error("Error deleting organization:", error);
            alert("An error occurred while deleting.");
        } finally {
            setIsLoading(false);
        }
    };

    const handleFreeze = async (id, status) => {
        try {
            const confirmMsg = status ? "Resume" : "Freeze";
            if (!window.confirm(`Are you sure you want to ${confirmMsg} this organization?`)) return;
            setIsLoading(true);

            const response = status ? await apiServices.resumeOrganization(id) : await apiServices.freezeOrganization(id);

            if (response && !response.error) {
                // Refetch the organization list after successful update
                const updatedResponse = await apiServices.getOrganizations();
                if (updatedResponse && updatedResponse.organization) {
                    const updatedOrganization = updatedResponse.organization.map(org => ({
                        username: org.auth_user.username,
                        org_name: org.company_name,
                        msa_doc: org.contract_doc,
                        created_date: org.created_at,
                        status: org.is_frozen,
                        id: org.id,
                        delete:org.is_delete
                    }))
                    setData(updatedOrganization);
                }
                else {
                    console.error("Error: Invalid response format from API");
                }
            }
        } catch (error) {
            console.error("Error freezing organization:", error);
        } finally {
            setIsLoading(false);
        }
    };

    const handleChangePage = (event, newPage) => {
        setPage(newPage);
    };

    const handleChangeRowsPerPage = (event) => {
        setRowsPerPage(parseInt(event.target.value, 10));
        setPage(0);
    };

    const handleClick = useCallback((id) => {
        setSelected((prevSelected) => {
            if (prevSelected.includes(id)) {
                return prevSelected.filter((selectedId) => selectedId !== id);
            } else {
                return [...prevSelected, id];
            }
        });
    }, [setSelected]);

    const handleSelectAllClick = (event) => {
        if (event.target.checked) {
            const newSelecteds = visibleRows.map((row) => row.id);
            setSelected(newSelecteds);
        } else {
            setSelected([]);
        }
    };

    const isSelected = useCallback((id) => selected.includes(id), [selected]);

    const sortData = useCallback((dataToSort, order, orderBy) => {
        return [...dataToSort].sort((a, b) => {
            let comparison = 0;
            if (orderBy === 'username') {
                comparison = a.username.localeCompare(b.username);
            } else if (orderBy === 'org_name') {
                comparison = a.org_name.localeCompare(b.org_name);
            } else if (orderBy === 'created_date') {
                comparison = new Date(a.created_date).getTime() - new Date(b.created_date).getTime();
            } else if (orderBy === 'status') {
                comparison = (a.status === b.status) ? 0 : (a.status ? -1 : 1);
            }

            return order === 'asc' ? comparison : -comparison;
        });
    }, []);

    const handleDateChange = (date) => {
        const formattedDate = date ? dayjs(date).format('DD-MM-YYYY') : '';
        setSelectedDate(date);
        setSearchTerm(formattedDate.toLowerCase());
        setPage(0);
        handleClose(); // Close Popover after selecting date
    };

    const filteredData = data.filter(org => {
        const formattedCreatedDate = dayjs(org.created_date).format('DD-MM-YYYY').toLowerCase();
        return (
            (!searchTerm ||
                org.username.toLowerCase().includes(searchTerm) ||
                org.org_name.toLowerCase().includes(searchTerm) ||
                formattedCreatedDate.includes(searchTerm)
            ) &&
            (!statusFilter || org.status.toString() === statusFilter)
        );
    });

    const handleAddOrganization = () => {
        navigate('/companycreation');
    };
    
    const handledeleteOrganization = () => {
        navigate(`/OrganizationDeleteList`);
      }

    const sortedData = useMemo(() => {
        return sortData(filteredData, order, orderBy);
    }, [filteredData, order, orderBy, sortData]);

    const visibleRows = sortedData.slice(page * rowsPerPage, page * rowsPerPage + rowsPerPage);
    const numSelected = selected.length;
    const rowCount = filteredData.length;
    return (
        <Box sx={{
            marginLeft: {
                xs: "0",
                sm: "0",
                md: "250px",
            },
            marginTop: "80px",
            width: {
                xs: '100%',
                sm: '100%',
                md: 'calc(100% - 250px)',
            },
            transition: 'width 0.3s ease-in-out',
            pr: 3,
            boxSizing: 'border-box'
        }}>
            <Typography 
                variant="h4" 
                gutterBottom 
                sx={{ 
                    fontWeight: 'bold', 
                    paddingRight: '20px', 
                    fontSize: '18px', 
                    color: '#000b58' // Added missing closing quote
                }}
            >
                Organization List
            </Typography>
            <Box sx={{
                display: 'flex',
                justifyContent: 'flex-end',
                mb: 2,
            }}>
                <Button
                    variant="contained"
                    sx={{
                        backgroundColor: 'black',
                        color: 'white',
                        fontSize: '12px',
                        borderRadius: '7px',
                        padding: '4px 8px',
                        marginTop: '-40px',
                        '&:hover': {
                            backgroundColor: '#424242',
                        },
                        mr:1
                    }}
                    onClick={handleAddOrganization}
                    startIcon={<AddIcon />}
                >
                    New Organization
                </Button>
                 <Button
                    variant="contained"
                    sx={{
                        backgroundColor: 'black',
                        color: 'white',
                        fontSize: '12px',
                        borderRadius: '7px',
                        padding: '4px 8px',
                        marginTop: '-40px',
                        '&:hover': {
                            backgroundColor: '#424242',
                        },
                    }}
                    onClick={handledeleteOrganization}
                >
                    Deleted List
                </Button>
            </Box>
            <Card sx={{
                width: '100%',
                minWidth: 600,
                padding: '1%',
                backgroundColor: theme.palette.background.paper,
                boxShadow: '0px 3px 5px rgba(0, 0, 0, 0.1)',
                borderRadius: '8px',
                border: `1px solid ${theme.palette.divider}`,
                background: theme.palette.grey[50],
                mx: 'auto',
                boxSizing: 'border-box'
            }}>
                <Box display="flex" justifyContent="space-between" mb={2}>
                    <OutlinedInput
                        value={searchTerm}
                        onChange={handleSearch}
                        placeholder="Search..."
                        sx={{
                            maxWidth: 260, fontSize: '14px',
                            '&:hover .MuiOutlinedInput-notchedOutline': {
                                borderColor: theme.palette.primary.main,
                            },
                            background: theme.palette.common.white,
                        }}
                        startAdornment={
                            <InputAdornment position="start">
                                <SearchIcon />
                            </InputAdornment>
                        }
                        endAdornment={
                            <InputAdornment position="end">
                                <IconButton onClick={handleCalendarClick}>
                                    <CalendarMonthIcon />
                                </IconButton>
                            </InputAdornment>
                        }
                    />
                    <FormControl variant="outlined" sx={{ minWidth: 250 }}>
                        <InputLabel id="status-label" sx={{ fontSize: '12px' }}>Status</InputLabel>
                        <Select
                            labelId="status-label"
                            value={statusFilter}
                            onChange={handleStatusFilter}
                            label="Status"
                            sx={{
                                fontSize: '14px',
                                '& .MuiSelect-select': { textDecoration: 'none' },
                                background: theme.palette.common.white,
                            }}
                        >
                            <MenuItem value="" sx={{ fontSize: '12px' }}>All</MenuItem>
                            <MenuItem value="false" sx={{ fontSize: '12px' }}>Active</MenuItem>
                            <MenuItem value="true" sx={{ fontSize: '12px' }}>Inactive</MenuItem>
                        </Select>
                    </FormControl>
                </Box>
                <Popover
                    id={id}
                    open={open}
                    anchorEl={anchorEl}
                    onClose={handleClose}
                    anchorOrigin={{
                        vertical: 'bottom',
                        horizontal: 'left',
                    }}
                >
                    <LocalizationProvider dateAdapter={AdapterDayjs} adapterLocale="en">
                        <DatePicker
                            value={selectedDate}
                            onChange={handleDateChange}
                            renderInput={() => { }}
                            format="DD-MM-YYYY"
                        />
                    </LocalizationProvider>
                </Popover>
                <TableContainer sx={{ width: '100%', maxHeight: '350px', overflowY: 'auto' }}>
                    <Table size="small" sx={{ width: '100%', minWidth: 650 }}>
                        <UserTableHead
                            order={order}
                            orderBy={orderBy}
                            onRequestSort={handleSort}
                            onSelectAllClick={handleSelectAllClick}
                            numSelected={numSelected}
                            rowCount={rowCount}
                        />
                        <TableBody>
                            {visibleRows.map(row => {
                                const isItemSelected = isSelected(row.id);
                                return (
                                    <UserTableRow
                                        key={row.id}
                                        row={row}
                                        handleEdit={handleEdit}
                                        handleDelete={handleDelete}
                                        isSelected={isItemSelected}
                                        handleClick={handleClick}
                                        handleFreeze={handleFreeze}  // Pass handleFreeze function
                                        url={url} // Pass url to UserTableRow
                                    />
                                );
                            })}
                            {filteredData.length === 0 && (
                                <TableRow>
                                    <TableCell colSpan={6} align="center" sx={{ fontSize: '12px' }}>No results found.</TableCell>
                                </TableRow>
                            )}
                        </TableBody>
                    </Table>
                </TableContainer>
                <TablePagination
                    rowsPerPageOptions={[5, 10, 25]}
                    count={filteredData.length}
                    rowsPerPage={rowsPerPage}
                    page={page}
                    onPageChange={handleChangePage}
                    onRowsPerPageChange={handleChangeRowsPerPage}
                    labelRowsPerPage="Rows per page:"
                    sx={{
                        display: 'flex',
                        justifyContent: 'flex-end',
                        alignItems: 'center',
                        //mt: 2,
                        fontSize: '12px',
                        background: theme.palette.common.white,
                        border: 'none',
                    }}
                    labelDisplayedRows={({ from, to, count }) => `${from}-${to} of ${count}`}
                />
            </Card>
            {isLoading && (
                <div className="loading-popup">
                    <div className="loading-popup-content">
                        <Loader type="box-up" bgColor={'#000b58'} color={'#000b58'} size={100} />
                        <p>Loading...</p>
                    </div>
                </div>
            )}
        </Box>
    );
};

export default OrganizationList;
