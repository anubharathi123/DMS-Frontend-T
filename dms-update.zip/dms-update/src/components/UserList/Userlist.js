import React, { useState, useEffect, useRef, useCallback, useMemo } from "react";
import {
    Box, Card, Table, Button, TableBody, Typography, TableContainer,
    TablePagination, TableRow, TableCell, TableHead, Select, MenuItem, Checkbox,
    FormControl, InputLabel, OutlinedInput, InputAdornment,
    IconButton, Menu, ListItemIcon, ListItemText, useTheme,
    TableSortLabel,
} from '@mui/material';
import SearchIcon from '@mui/icons-material/Search';
import DeleteIcon from '@mui/icons-material/Delete';
import EditIcon from '@mui/icons-material/Edit';
import MoreVertIcon from '@mui/icons-material/MoreVert';
import AddIcon from '@mui/icons-material/Add';
import ToggleOffIcon from '@mui/icons-material/ToggleOff';
import ToggleOnIcon from '@mui/icons-material/ToggleOn';
import apiServices from "../../ApiServices/ApiServices";
import { DatePicker } from '@mui/x-date-pickers/DatePicker';
import { AdapterDayjs } from '@mui/x-date-pickers/AdapterDayjs';
import { LocalizationProvider } from '@mui/x-date-pickers/LocalizationProvider';
import CalendarMonthIcon from '@mui/icons-material/CalendarMonth';
import { styled } from '@mui/system';
import { useNavigate } from 'react-router-dom';
import dayjs from 'dayjs';

const StatusIndicator = styled(Box)(({ status }) => ({
    display: 'inline-block',
    padding: '4px 8px',
    borderRadius: '4px',
    fontSize: '12px',
    fontWeight: 'bold',
    color: 'black',
    backgroundColor: status === 'Active' ? '#A5D6A7' : status === 'Inactive' ? '#F44336' : '#9E9E9E',
}));

const headLabel = [
    { id: 'username', label: 'Username', align: 'left', width: '15%' },
    { id: 'email', label: 'Email', align: 'left', width: '20%' },
    { id: 'createdAt', label: 'Created Date', align: 'left', width: '15%' },
    { id: 'role', label: 'Role', align: 'center', width: '10%' },
    { id: 'status', label: 'Status', align: 'center', width: '10%' },
    { id: 'actions', label: 'Actions', align: 'center', width: '10%' },
];

const EnhancedTableHead = ({ order, orderBy, onRequestSort, onSelectAllClick, numSelected, rowCount }) => {
    const createSortHandler = (property) => (event) => {
        onRequestSort(event, property);
    };

    const theme = useTheme();

    return (
        <TableHead sx={{
            background: theme.palette.grey[100],
            borderBottom: `1px solid ${theme.palette.divider}`,
        }}>
            <TableRow>
                <TableCell padding="checkbox">
                    <Checkbox
                        indeterminate={numSelected > 0 && numSelected < rowCount}
                        checked={rowCount > 0 && numSelected === rowCount}
                        onChange={onSelectAllClick}
                        inputProps={{
                            'aria-label': 'select all desserts',
                        }}
                    />
                </TableCell>
                {headLabel.map((headCell) => (
                    <TableCell
                        key={headCell.id}
                        align={headCell.align}
                        padding="normal"
                        sortDirection={orderBy === headCell.id ? order : false}
                        sx={{
                            fontWeight: '600',
                            padding: '12px 8px',
                            whiteSpace: 'nowrap',
                            width: headCell.width,
                            color: theme.palette.text.primary,
                            fontSize: '14px',
                            '& .MuiTableSortLabel-root': {
                                color: theme.palette.text.primary,
                                '&:hover': {
                                    color: theme.palette.primary.main,
                                },
                                '&.Mui-active': {
                                    color: theme.palette.primary.main,
                                },
                            },
                        }}
                    >
                        <TableSortLabel
                            active={orderBy === headCell.id}
                            direction={orderBy === headCell.id ? order : 'asc'}
                            onClick={createSortHandler(headCell.id)}
                        >
                            {headCell.label}
                        </TableSortLabel>
                    </TableCell>
                ))}
            </TableRow>
        </TableHead>
    );
};

const UserTableRow = ({ row, handleEdit, handleDelete, handleFreeze, selected, setSelected, handleClick }) => {
    const [anchorEl, setAnchorEl] = useState(null);
    const open = Boolean(anchorEl);
    const theme = useTheme();

    const handleMenuClick = (event) => {
        setAnchorEl(event.currentTarget);
    };

    const handleMenuClose = () => {
        setAnchorEl(null);
    };

    const getStatus = () => {
        return row.status ? "Inactive" : "Active";
    };

    return (
        <TableRow
            hover
            onClick={(event) => handleClick(event, row.id)}
            role="checkbox"
            aria-checked={selected}
            tabIndex={-1}
            key={row.id}
            selected={selected}
            sx={{
                '&:nth-of-type(odd)': {
                    backgroundColor: theme.palette.grey[50],
                },
                '&:hover': {
                    backgroundColor: theme.palette.grey[100],
                },
                '&.Mui-selected': {
                    backgroundColor: theme.palette.grey[200],
                },
            }}
        >
            <TableCell padding="checkbox">
                <Checkbox
                    checked={selected}
                    inputProps={{
                        'aria-labelledby': `enhanced-table-checkbox-${row.id}`,
                    }}
                />
            </TableCell>
            <TableCell sx={{ padding: '8px', whiteSpace: 'nowrap', color: theme.palette.text.primary, fontSize: '12px' }}
                component="th"
                id={`enhanced-table-checkbox-${row.id}`}
                scope="row">
                {row.username}</TableCell>
            <TableCell sx={{ padding: '8px', whiteSpace: 'nowrap', color: theme.palette.text.primary, fontSize: '12px' }}>{row.email}</TableCell>
            <TableCell sx={{ padding: '8px', whiteSpace: 'nowrap', color: theme.palette.text.primary, fontSize: '12px' }}>
                {new Date(row.createdAt).toLocaleDateString("en-US", { year: "numeric", month: "long", day: "numeric" })}
            </TableCell>
            <TableCell align="center" sx={{ padding: '8px' }}>
                <StatusIndicator status={row.role}>
                    {row.role}
                </StatusIndicator>
            </TableCell>
            <TableCell align="center" sx={{ padding: '8px' }}>
                <StatusIndicator status={getStatus()}>
                    {getStatus()}
                </StatusIndicator>
            </TableCell>
            <TableCell align="center" sx={{ padding: '8px', whiteSpace: 'nowrap' }}>
                <IconButton
                    aria-label="more"
                    id="long-button"
                    aria-controls={open ? 'long-menu' : undefined}
                    aria-expanded={open ? 'true' : undefined}
                    aria-haspopup="true"
                    onClick={handleMenuClick}
                >
                    <MoreVertIcon />
                </IconButton>
                <Menu
                    id="long-menu"
                    MenuListProps={{
                        'aria-labelledby': 'long-button',
                    }}
                    anchorEl={anchorEl}
                    open={open}
                    onClose={handleMenuClose}
                    PaperProps={{
                        style: {
                            width: 'auto',
                            boxShadow: '0px 2px 10px rgba(0, 0, 0, 0.1)',
                        },
                    }}
                >
                    <MenuItem onClick={() => { handleEdit(row.id); handleMenuClose(); }} sx={{ fontSize: '12px', '&:hover': { backgroundColor: theme.palette.grey[100] } }}>
                        <ListItemIcon>
                            <EditIcon style={{ fontSize: '16px' }} />
                        </ListItemIcon>
                        <ListItemText>Edit</ListItemText>
                    </MenuItem>
                    <MenuItem onClick={() => { handleFreeze(row.id, row.orgId, row.status); handleMenuClose(); }} sx={{ fontSize: '12px', '&:hover': { backgroundColor: theme.palette.grey[100] } }}>
                        <ListItemIcon>
                            {row.status ? <ToggleOffIcon style={{ fontSize: '16px' }} /> : <ToggleOnIcon style={{ fontSize: '16px' }} />}
                        </ListItemIcon>
                        <ListItemText>{row.status ? "Resume" : "Freeze"}</ListItemText>
                    </MenuItem>
                    <MenuItem onClick={() => { handleDelete(row.id); handleMenuClose(); }} sx={{ fontSize: '12px', '&:hover': { backgroundColor: theme.palette.grey[100] } }}>
                        <ListItemIcon>
                            <DeleteIcon style={{ fontSize: '16px' }} />
                        </ListItemIcon>
                        <ListItemText>Delete</ListItemText>
                    </MenuItem>
                </Menu>
            </TableCell>
        </TableRow>
    );
};

const UserList = () => {
    const [data, setData] = useState([]);
    const [actionMessage, setActionMessage] = useState("");
    const [showSearchInfo, setShowSearchInfo] = useState(false);
    const [searchTerm, setSearchTerm] = useState("");
    const [filter, setFilter] = useState("");
    const [rowsPerPage, setRowsPerPage] = useState(5);
    const [isCalendarOpen, setIsCalendarOpen] = useState(false);
    const [filterDate, setFilterDate] = useState(null);
    const [currentPage, setCurrentPage] = useState(1);
    const [filteredData, setFilteredData] = useState([]);
    const [isLoading, setIsLoading] = useState(false);
    const [refresh, setRefresh] = useState(false);
    const calendarRef = useRef(null);
    const searchInfoRef = useRef(null);
    const navigate = useNavigate();
    const theme = useTheme();
    const [selected, setSelected] = React.useState([]);

    // Sorting states and functions
    const [order, setOrder] = useState('asc');
    const [orderBy, setOrderBy] = useState('username');

    useEffect(() => {
        const handleClickOutside = (event) => {
            if (searchInfoRef.current && !searchInfoRef.current.contains(event.target)) {
                setShowSearchInfo(false);
            }
        };

        if (showSearchInfo) {
            document.addEventListener("mousedown", handleClickOutside);
        }

        return () => {
            document.removeEventListener("mousedown", handleClickOutside);
        };
    }, [showSearchInfo]);

    useEffect(() => {
        const fetchDetails = async () => {
            try {
                setIsLoading(true);
                const response = await apiServices.users();
                let users = response.map((user) => ({
                    id: user.id,
                    orgId: user.organization.id,
                    username: user.auth_user.first_name || "N/A",
                    email: user.auth_user.email,
                    createdAt: user.created_at,
                    role: user.role.name.toLowerCase(), // Store role in lowercase for easier comparison
                    status: user.is_frozen,
                    delete: user.is_delete,
                }));
                const filteredUsers = users.filter(item => !item.delete);
                setData(filteredUsers);
                setFilteredData(filteredUsers);
                if (users.length === 0) {
                    setActionMessage("No users available.");
                }
            } catch (error) {
                console.error("Error Fetching users:", error);
                setActionMessage("Error fetching users. Please try again later.");
            } finally {
                setIsLoading(false);
            }
        };
        fetchDetails();
    }, [refresh]);

    const filteredData1 = useMemo(() => {
        return filteredData.filter((item) => {
            const searchValue = searchTerm.toLowerCase();

            const usernameMatch = item.username.toLowerCase().includes(searchValue);
            const emailMatch = item.email.toLowerCase().includes(searchValue);
            const createdAtMatch = item.createdAt ? new Date(item.createdAt).toLocaleDateString().toLowerCase().includes(searchValue) : false;
            const roleMatch = item.role.toLowerCase().includes(searchValue);
            const statusMatch = (item.status ? "inactive" : "active").toLowerCase().includes(searchValue);

            let roleFilterMatch = true;
            if (filter !== "") {
                roleFilterMatch = item.role === filter;
            }

            return roleFilterMatch && (usernameMatch || emailMatch || createdAtMatch || roleMatch || statusMatch);
        });
    }, [filteredData, searchTerm, filter]);

    useEffect(() => {
        const filterUsers = data.filter((item) => {
            if (filterDate) {
                const itemDate = new Date(item.createdAt);
                const selectedDate = new Date(filterDate);
                return itemDate.toLocaleDateString() === selectedDate.toLocaleDateString();
            }
            return true;
        });
        setFilteredData(filterUsers);
    }, [filterDate, data]);

    // Sorting function
    const handleRequestSort = (event, property) => {
        const isAsc = orderBy === property && order === 'asc';
        setOrder(isAsc ? 'desc' : 'asc');
        setOrderBy(property);
    };

    const sortData = (data, order, orderBy) => {
        return [...data].sort((a, b) => {
            let comparison = 0;

            if (orderBy === 'username') {
                comparison = a.username.localeCompare(b.username);
            } else if (orderBy === 'email') {
                comparison = a.email.localeCompare(b.email);
            } else if (orderBy === 'createdAt') {
                comparison = new Date(a.createdAt).getTime() - new Date(b.createdAt).getTime();
            } else if (orderBy === 'role') {
                comparison = a.role.localeCompare(b.role);
            } else if (orderBy === 'status') {
                comparison = (a.status === b.status) ? 0 : (a.status ? -1 : 1);
            }

            if (order === 'desc') {
                comparison = comparison * -1;
            }
            return comparison;
        });
    };

    const sortedData = useMemo(() => {
        return sortData(filteredData1, order, orderBy);
    }, [filteredData1, order, orderBy]);

    const paginatedData = sortedData.filter(item => !item.delete).slice((currentPage - 1) * rowsPerPage, currentPage * rowsPerPage + rowsPerPage);

    const handleCreateUser = () => {
        navigate(`/createuser`);
    }

    const handleEditAdmin = (id) => {
        navigate(`/UpdateUser/${id}`);
    };

    const handleFreeze = async (id, orgId, status) => {
        try {
            const confirmMsg = status ? "Resume" : "Freeze";
            if (!window.confirm(`Are you sure you want to ${confirmMsg} this user?`)) return;
            setIsLoading(true);

            const response = status ? await apiServices.resumeEmployee(orgId, id) : await apiServices.freezeEmployee(orgId, id);

            if (response && !response.error) {
                setRefresh(prev => !prev)
            }
        } catch (error) {
            console.error("Error freezing user:", error);
        } finally {
            setIsLoading(false);
        }
    };

    const handleDeleteUser = async (id) => {
        const confirmMsg = `Are you sure you want to delete user "${id}"?`;
        if (!window.confirm(confirmMsg)) return;

        try {
            setIsLoading(true);
            const response = await apiServices.deleteAdmin(id);

            if (response && !response.error) {
                setRefresh(prev => !prev)

            } else {
                setActionMessage(response?.data?.message || "Failed to delete user.");
            }
        } catch (error) {
            console.error("Error deleting user:", error);
            setActionMessage("Error deleting user. Please try again.");
        } finally {
            setIsLoading(false);
        }
    };

    const handleResetFilter = (e) => {
        setSearchTerm('');
        setFilter(e.target.value);
        setFilterDate(null);
        setIsCalendarOpen(false);
        setCurrentPage(1);
    };
    const handleSearch = (e) => setSearchTerm(e.target.value);
    const handleSearchInfo = () => setShowSearchInfo(!showSearchInfo);
    const handleFilter = (e) => setFilter(e.target.value);
    const handleRowsPerPage = (e) => setRowsPerPage(parseInt(e.target.value));
    const handleCalendarToggle = () => setIsCalendarOpen((prev) => !prev);
    const handlePageChange = (pageNumber) => setCurrentPage(pageNumber);
    const handleDelete = () => { navigate('/deletedusers') }

    const handleSelectAllClick = (event) => {
        if (event.target.checked) {
            const newSelecteds = paginatedData.map((n) => n.id);
            setSelected(newSelecteds);
            return;
        }
        setSelected([]);
    };

    const handleClick = (event, name) => {
        const selectedIndex = selected.indexOf(name);
        let newSelected = [];

        if (selectedIndex === -1) {
            newSelected = newSelected.concat(selected, name);
        } else if (selectedIndex === 0) {
            newSelected = newSelected.concat(selected.slice(1));
        } else if (selectedIndex === selected.length - 1) {
            newSelected = newSelected.concat(selected.slice(0, -1));
        } else if (selectedIndex > 0) {
            newSelected = newSelected.concat(
                selected.slice(0, selectedIndex),
                selected.slice(selectedIndex + 1),
            );
        }

        setSelected(newSelected);
    };

    const isSelected = (name) => selected.indexOf(name) !== -1;

    const numSelected = selected.length;
    const rowCount = paginatedData.length;

    const handleDateChange = (date) => {
        setFilterDate(date);
        setIsCalendarOpen(false); // Close the calendar after selecting a date
    };

    return (
        <LocalizationProvider dateAdapter={AdapterDayjs}>
            <Box sx={{
                marginLeft: {
                    xs: "0",
                    sm: "0",
                    md: "250px",
                },
                marginTop: "80px",
                width: {
                    xs: '100%',
                    sm: '100%',
                    md: 'calc(100% - 250px)',
                },
                transition: 'width 0.3s ease-in-out',
                pr: 3,
                boxSizing: 'border-box'
            }}>
                <Typography variant="h4" gutterBottom sx={{ fontWeight: 'bold', paddingRight: '20px', fontSize: '18px', color: '#000b58' }}>
                    User List
                </Typography>
                <Box sx={{
                    display: 'flex',
                    justifyContent: 'flex-end',
                    mb: 2,
                }}>
                    <Button
                        variant="contained"
                        sx={{
                            backgroundColor: 'black',
                            color: 'white',
                            fontSize: '12px',
                            borderRadius: '7px',
                            padding: '4px 8px',
                            marginTop: '-40px',
                            '&:hover': {
                                backgroundColor: '#424242',
                            },
                        }}
                        onClick={handleCreateUser}
                        startIcon={<AddIcon />}
                    >
                        New User
                    </Button>
                    <Button
                        variant="contained"
                        sx={{
                            backgroundColor: 'black',
                            color: 'white',
                            fontSize: '12px',
                            borderRadius: '7px',
                            padding: '4px 8px',
                            marginTop: '-40px',
                            marginLeft: '10px',
                            '&:hover': {
                                backgroundColor: '#424242',
                            },
                        }}
                        onClick={handleDelete}
                    >
                        Deleted User List
                    </Button>
                </Box>
                <Card sx={{
                    width: '100%',
                    minWidth: 600,
                    padding: '1%',
                    backgroundColor: theme.palette.background.paper,
                    boxShadow: '0px 3px 5px rgba(0, 0, 0, 0.1)',
                    borderRadius: '8px',
                    border: `1px solid ${theme.palette.divider}`,
                    background: theme.palette.grey[50],
                    mx: 'auto',
                    boxSizing: 'border-box'
                }}>
                    <Box display="flex" justifyContent="space-between" mb={2}>
                        <OutlinedInput
                            value={searchTerm}
                            onChange={handleSearch}
                            placeholder="Search..."
                            sx={{
                                maxWidth: 260, fontSize: '14px',
                                '&:hover .MuiOutlinedInput-notchedOutline': {
                                    borderColor: theme.palette.primary.main,
                                },
                                background: theme.palette.common.white,
                            }}
                            startAdornment={
                                <InputAdornment position="start">
                                    <SearchIcon />
                                </InputAdornment>
                            }
                            endAdornment={
                                <InputAdornment position="end">
                                    <IconButton onClick={() => setIsCalendarOpen(true)}> {/* Open calendar directly */}
                                        <CalendarMonthIcon />
                                    </IconButton>
                                    {isCalendarOpen && (
                                        <Box sx={{ position: 'absolute', zIndex: 1, mt: 1 }}>{/* Calendar always visible when open */}
                                            <DatePicker
                                                value={filterDate}
                                                onChange={handleDateChange}
                                                onClose={() => setIsCalendarOpen(false)}
                                                renderInput={() => { }}
                                            />
                                        </Box>
                                    )}
                                </InputAdornment>
                            }
                        />
                        <FormControl variant="outlined" sx={{ minWidth: 250 }}>
                            <InputLabel id="role-label" sx={{ fontSize: '12px' }}>Filter by Role</InputLabel>
                            <Select
                                labelId="role-label"
                                value={filter}
                                onChange={handleFilter}
                                label="Filter by Role"
                                sx={{
                                    fontSize: '14px',
                                    '& .MuiSelect-select': { textDecoration: 'none' },
                                    background: theme.palette.common.white,
                                }}
                            >
                                <MenuItem value="" sx={{ fontSize: '12px' }}>All Roles</MenuItem>
                                <MenuItem value="product_admin" sx={{ fontSize: '12px' }}>Product Admin</MenuItem>
                                <MenuItem value="user" sx={{ fontSize: '12px' }}>User</MenuItem>
                            </Select>
                        </FormControl>
                    </Box>
                    <TableContainer sx={{ width: '100%', maxHeight: '350px', overflowY: 'auto' }}>
                        <Table size="small" sx={{ width: '100%', minWidth: 650 }}>
                            <EnhancedTableHead
                                numSelected={numSelected}
                                onRequestSort={handleRequestSort}
                                onSelectAllClick={handleSelectAllClick}
                                rowCount={rowCount}
                                order={order}
                                orderBy={orderBy}
                            />
                            <TableBody>
                                {paginatedData.map(row => {
                                    const isItemSelected = isSelected(row.id);
                                    const labelId = `enhanced-table-checkbox-${row.id}`;

                                    return (
                                        <UserTableRow
                                            key={row.id}
                                            row={row}
                                            handleEdit={() => handleEditAdmin(row.id)}
                                            handleDelete={() => handleDeleteUser(row.id)}
                                            handleFreeze={handleFreeze}
                                            selected={isItemSelected}
                                            setSelected={setSelected}
                                            handleClick={handleClick}
                                        />
                                    );
                                })}
                                {filteredData1.length === 0 && (
                                    <TableRow>
                                        <TableCell colSpan={headLabel.length} align="center" sx={{ fontSize: '12px' }}>No results found.</TableCell>
                                    </TableRow>
                                )}
                            </TableBody>
                        </Table>
                    </TableContainer>
                    <TablePagination
                        rowsPerPageOptions={[5, 10, 25]}
                        component="div"
                        count={filteredData1.length}
                        rowsPerPage={rowsPerPage}
                        page={currentPage - 1}
                        onPageChange={(e, newPage) => handlePageChange(newPage + 1)}
                        onRowsPerPageChange={handleRowsPerPage}
                        labelRowsPerPage="Rows per page:"
                        sx={{
                            display: 'flex',
                            justifyContent: 'flex-end',
                            alignItems: 'center',
                            fontSize: '12px',
                            background: theme.palette.common.white,
                            border: 'none',
                        }}
                        labelDisplayedRows={({ from, to, count }) => `${from}-${to} of ${count}`}
                    />
                </Card>
            </Box>
        </LocalizationProvider>
    );
};

export default UserList;
