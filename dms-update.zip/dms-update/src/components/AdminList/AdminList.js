import React, { useState, useEffect, useCallback, useMemo, useRef } from 'react';
import {
    Box, Card, Table, Button, TableBody, Typography, TableContainer,
    TablePagination, TableRow, TableCell, TableHead, Select, MenuItem,
    FormControl, InputLabel, TableSortLabel, Tooltip, OutlinedInput, InputAdornment,
    IconButton, Menu, ListItemIcon, ListItemText, useTheme, useMediaQuery, Popover
} from '@mui/material';
import SearchIcon from '@mui/icons-material/Search';
import DeleteIcon from '@mui/icons-material/Delete';
import EditIcon from '@mui/icons-material/Edit';
import MoreVertIcon from '@mui/icons-material/MoreVert';
import AddIcon from '@mui/icons-material/Add';
import apiServices from '../../ApiServices/ApiServices';
import Checkbox from '@mui/material/Checkbox';
import { styled } from '@mui/system';
import { useNavigate, useParams } from 'react-router-dom'; // Import useParams
import { DatePicker } from '@mui/x-date-pickers/DatePicker';
import { AdapterDayjs } from '@mui/x-date-pickers/AdapterDayjs';
import { LocalizationProvider } from '@mui/x-date-pickers/LocalizationProvider';
import dayjs from 'dayjs';
import 'dayjs/locale/en';
import CalendarMonthIcon from '@mui/icons-material/CalendarMonth';
import Loader from "react-js-loader"; // Ensure Loader is imported
import { FontAwesomeIcon } from '@fortawesome/react-fontawesome'
import { faToggleOff, faToggleOn } from '@fortawesome/free-solid-svg-icons';

const StatusIndicator = styled(Box)(({ status }) => ({
    display: 'inline-block',
    padding: '4px 8px',
    borderRadius: '4px',
    fontSize: '12px',
    fontWeight: 'bold',
    color: 'black',
    backgroundColor: status === 'Active' ? '#A5D6A7' : status === 'Inactive' ? '#F44336' : '#9E9E9E',
}));

const headLabel = [
    { id: 'checkbox', label: '', align: 'center', width: '5%' }, // Added checkbox column
    { id: 'username', label: 'Username', align: 'left', width: '15%' },
    { id: 'name', label: 'Name', align: 'left', width: '20%' },
    { id: 'email', label: 'Email', align: 'left', width: '20%' },
    { id: 'createdAt', label: 'Created Date', align: 'left', width: '15%' },
    { id: 'role', label: 'Role', align: 'center', width: '10%' },
    { id: 'status', label: 'Status', align: 'center', width: '10%' },
    { id: 'actions', label: 'Actions', align: 'center', width: '10%' },
];

const UserTableHead = ({ order, orderBy, onRequestSort, onSelectAllClick, numSelected, rowCount }) => {
    const createSortHandler = (property) => (event) => {
        onRequestSort(event, property);
    };
    const theme = useTheme();
    return (
        <TableHead sx={{
            background: theme.palette.grey[100],
            borderBottom: `1px solid ${theme.palette.divider}`,
        }}>
            <TableRow>
                <TableCell padding="checkbox" sx={{ padding: '0px 4px' }}>
                    <Checkbox
                        indeterminate={numSelected > 0 && numSelected < rowCount}
                        checked={rowCount > 0 && numSelected === rowCount}
                        onChange={onSelectAllClick}
                        inputProps={{ 'aria-label': 'select all users' }}
                        sx={{
                            color: theme.palette.grey[600],
                            '&.Mui-checked': {
                                color: theme.palette.primary.main,
                            },
                            '& .MuiSvgIcon-root': {
                                fontSize: 16,
                            },
                        }}
                    />
                </TableCell>
                {headLabel.slice(1).map((headCell) => ( // Skip checkbox column here
                    <TableCell
                        key={headCell.id}
                        align={headCell.align}
                        sx={{
                            fontWeight: '600',
                            padding: '12px 8px',
                            whiteSpace: 'nowrap',
                            width: headCell.width,
                            color: theme.palette.text.primary,
                            fontSize: '14px',
                            '& .MuiTableSortLabel-root': {
                                color: theme.palette.text.primary,
                                '&:hover': {
                                    color: theme.palette.primary.main,
                                },
                                '&.Mui-active': {
                                    color: theme.palette.primary.main,
                                },
                            },
                        }}
                    >
                        <TableSortLabel
                            active={orderBy === headCell.id}
                            direction={orderBy === headCell.id ? order : 'asc'}
                            onClick={createSortHandler(headCell.id)}
                        >
                            {headCell.label}
                        </TableSortLabel>
                    </TableCell>
                ))}
            </TableRow>
        </TableHead>
    );
};
const UserTableRow = ({ row, handleEdit, handleDelete, isSelected, handleClick, handleFreeze }) => {
    const [anchorEl, setAnchorEl] = useState(null);
    const open = Boolean(anchorEl);
    const theme = useTheme();
    const navigate = useNavigate(); // Get navigate function from useNavigate
    const handleMenuClick = (event) => {
        setAnchorEl(event.currentTarget);
    };
    const handleMenuClose = () => {
        setAnchorEl(null);
    };

    const getStatus = (isFrozen, role) => {
        if (isFrozen) {
            return "Inactive";
        } else {
            return role === 'PRODUCT_ADMIN' ? "Active" : "Inactive";
        }
    };

    const status = getStatus(row.is_frozen, row.role);
    return (
        <TableRow
            hover
            role="checkbox"
            aria-checked={isSelected}
            selected={isSelected}
            sx={{
                '&:nth-of-type(odd)': {
                    backgroundColor: theme.palette.grey[50],
                },
                '&:hover': {
                    backgroundColor: theme.palette.grey[100],
                },
                '&.Mui-selected': {
                    backgroundColor: theme.palette.grey[200],
                },
            }}
        >
            <TableCell padding="checkbox" sx={{ padding: '0px 4px' }}>
                <Checkbox checked={isSelected} onChange={(event) => handleClick(row.id)}
                    sx={{
                        '& .MuiSvgIcon-root': {
                            fontSize: 16,
                        },
                    }} />
            </TableCell>
            <TableCell sx={{ padding: '8px', whiteSpace: 'nowrap', color: theme.palette.text.primary, fontSize: '12px' }}>{row.username}</TableCell>
            <TableCell sx={{ padding: '8px', whiteSpace: 'nowrap', color: theme.palette.text.primary, fontSize: '12px' }}>
                <Tooltip title={row.name} arrow>
                    <span>{row.name.length > 20 ? `${row.name.substring(0, 20)}...` : row.name}</span>
                </Tooltip>
            </TableCell>
            <TableCell sx={{ padding: '8px', whiteSpace: 'nowrap', color: theme.palette.text.primary, fontSize: '12px' }}>
                <Tooltip title={row.email} arrow>
                    <span>{row.email.length > 20 ? `${row.email.substring(0, 20)}...` : row.email}</span>
                </Tooltip>
            </TableCell>
            <TableCell sx={{ padding: '8px', whiteSpace: 'nowrap', color: theme.palette.text.primary, fontSize: '12px' }}>{new Date(row.createdAt).toLocaleDateString()}</TableCell>
            <TableCell align="center" sx={{ padding: '8px' }}>
                {row.role}
            </TableCell>
            <TableCell align="center" sx={{ padding: '8px' }}>
                <StatusIndicator status={status}>
                    {status}
                </StatusIndicator>
            </TableCell>
            <TableCell align="center" sx={{ padding: '8px', whiteSpace: 'nowrap' }}>
                <IconButton
                    aria-label="more"
                    id="long-button"
                    aria-controls={open ? 'long-menu' : undefined}
                    aria-expanded={open ? 'true' : undefined}
                    aria-haspopup="true"
                    onClick={handleMenuClick}
                >
                    <MoreVertIcon />
                </IconButton>
                <Menu
                    id="long-menu"
                    MenuListProps={{
                        'aria-labelledby': 'long-button',
                    }}
                    anchorEl={anchorEl}
                    open={open}
                    onClose={handleMenuClose}
                    PaperProps={{
                        style: {
                            width: 'auto',
                            boxShadow: '0px 2px 10px rgba(0, 0, 0, 0.1)',
                        },
                    }}
                >
                    <MenuItem onClick={() => {
                        handleFreeze(row.id, row.OrgId, row.is_frozen);
                        handleMenuClose();
                    }} sx={{ fontSize: '12px', '&:hover': { backgroundColor: theme.palette.grey[100] } }}>
                        <ListItemIcon>
                            <FontAwesomeIcon icon={row.is_frozen ? faToggleOn : faToggleOff} style={{ fontSize: '16px' }} />
                        </ListItemIcon>
                        <ListItemText>{row.is_frozen ? "Resume" : "Freeze"}</ListItemText>
                    </MenuItem>
                    <MenuItem onClick={() => { 
                        handleEdit(row.id); 
                        handleMenuClose(); 
                    }} sx={{ fontSize: '12px', '&:hover': { backgroundColor: theme.palette.grey[100] } }}>
                        <ListItemIcon>
                            <EditIcon style={{ fontSize: '16px' }} />
                        </ListItemIcon>
                        <ListItemText>Edit</ListItemText>
                    </MenuItem>
                    <MenuItem onClick={() => { handleDelete(row.id); handleMenuClose(); }} sx={{ fontSize: '12px', '&:hover': { backgroundColor: theme.palette.grey[100] } }}>
                        <ListItemIcon>
                            <DeleteIcon style={{ fontSize: '16px' }} />
                        </ListItemIcon>
                        <ListItemText>Delete</ListItemText>
                    </MenuItem>
                </Menu>
            </TableCell>
        </TableRow>
    );
};

const AdminList = () => {
    const [data, setData] = useState([]);
    const [searchTerm, setSearchTerm] = useState('');
    const [statusFilter, setStatusFilter] = useState('');
    const [order, setOrder] = useState('asc');
    const [orderBy, setOrderBy] = useState('username');
    const [page, setPage] = useState(0);
    const [rowsPerPage, setRowsPerPage] = useState(5);
    const [selected, setSelected] = useState([]);
    const theme = useTheme();
    const navigate = useNavigate();
    const isSmallScreen = useMediaQuery(theme.breakpoints.down('md'));
    const [anchorEl, setAnchorEl] = useState(null);  // for Popover
    const [selectedDate, setSelectedDate] = useState(null);
    const [isLoading, setIsLoading] = useState(false); // Loading state
    const { adminId } = useParams(); // Get the adminId from the URL
    const [selectedAdmin, setSelectedAdmin] = useState(null);
    const [filteredData, setFilteredData] = useState([]);// filter data useState

    const handleCalendarClick = (event) => {
        setAnchorEl(event.currentTarget); // Open the popover
    };

    const handleClose = () => {
        setAnchorEl(null); // Close the popover
    };

    const open = Boolean(anchorEl); // Check if popover is open
    const id = open ? 'date-picker-popover' : undefined;

    useEffect(() => {
        const fetchAdmins = async () => {
            try {
                setIsLoading(true);
                let adminsData;

                if (adminId) {
                    // If adminId is present, fetch details for a single admin
                    const response = await apiServices.getAdminById(adminId); // Assuming you have this API
                    console.log("Single Admin Response:", response);
                    adminsData = [response]; // Wrap the single admin object in an array
                    setSelectedAdmin(response);
                } else {
                    // Otherwise, fetch all admins
                    const response = await apiServices.getAdmins(); // Adjust based on API
                    console.log("All Admins Response:", response);
                    adminsData = response.product_admins;
                }

                if (adminsData) {
                    const admins = adminsData.map(admin => ({
                        id: admin.id,
                        username: admin.auth_user.username,
                        name: admin.auth_user.first_name,
                        email: admin.auth_user.email,
                        createdAt: admin.created_at,
                        status: admin.is_frozen,
                        OrgId: admin.organization.id,
                        role: admin.role.name,
                        delete: admin.is_delete,
                        is_frozen: admin.is_frozen
                    })).sort((a, b) => new Date(b.createdAt) - new Date(a.createdAt));
                    const filterdata = admins.filter(item => !item.delete)
                    setData(filterdata);
                    setFilteredData(filterdata);
                } else {
                    console.error("Error: Invalid response format from API");
                }
            } catch (error) {
                console.error("Error fetching admins:", error);
            } finally {
                setIsLoading(false); // End loading
            }
        };

        fetchAdmins();
    }, [adminId]);

    const handleSearch = (e) => {
        setSearchTerm(e.target.value.toLowerCase());
        setPage(0);
    };

    const handleStatusFilter = (e) => {
        setStatusFilter(e.target.value);
        setPage(0);
    };

    const handleSort = (event, property) => {
        const isAsc = orderBy === property && order === 'asc';
        setOrder(isAsc ? 'desc' : 'asc');
        setOrderBy(property);
    };

    const handleEdit = (id) => {
        navigate(`/updateadmin/${id}`);
    };

    const handleDelete = async (id) => {
        const confirmDelete = window.confirm(`Are you sure you want to delete admin "${id}"?`);

        if (confirmDelete) {
            try {
                setIsLoading(true);
                await apiServices.deleteAdmin(id);
                setData((prevData) => prevData.filter(admin => admin.id !== id));
            } catch (error) {
                console.error("Error deleting admin:", error);
            } finally {
                setIsLoading(false);
            }
        }
    };

    const handleChangePage = (event, newPage) => {
        setPage(newPage);
    };

    const handleChangeRowsPerPage = (event) => {
        setRowsPerPage(parseInt(event.target.value, 10));
        setPage(0);
    };
    const handleClick = useCallback((id) => {
        setSelected((prevSelected) => {
            if (prevSelected.includes(id)) {
                return prevSelected.filter((selectedId) => selectedId !== id);
            } else {
                return [...prevSelected, id];
            }
        });
    }, [setSelected]);

    const handleSelectAllClick = (event) => {
        if (event.target.checked) {
            const newSelecteds = visibleRows.map((row) => row.id);
            setSelected(newSelecteds);
        } else {
            setSelected([]);
        }
    };

    const isSelected = useCallback((id) => selected.includes(id), [selected]);

    const sortData = useCallback((dataToSort, order, orderBy) => {
        return [...dataToSort].sort((a, b) => {
            let comparison = 0;
            if (orderBy === 'username') {
                comparison = a.username.localeCompare(b.username);
            } else if (orderBy === 'name') {
                comparison = a.name.localeCompare(b.name);
            } else if (orderBy === 'email') {
                comparison = a.email.localeCompare(b.email);
            } else if (orderBy === 'createdAt') {
                comparison = new Date(a.createdAt).getTime() - new Date(b.createdAt).getTime();
            } else if (orderBy === 'role') {
                comparison = a.role.localeCompare(b.role);
            }

            return order === 'asc' ? comparison : -comparison;
        });
    }, []);

    const handleDateChange = (date) => {
        const formattedDate = date ? dayjs(date).format('DD-MM-YYYY') : '';
        setSelectedDate(date);
        setSearchTerm(formattedDate.toLowerCase());
        setPage(0);
        handleClose(); // Close Popover after selecting date
    };

    const getStatus = (isFrozen, role) => {
        if (isFrozen) {
            return "Inactive";
        } else {
            return role === 'PRODUCT_ADMIN' ? "Active" : "Inactive";
        }
    };

    useEffect(() => {
        const filterData = () => {
            const formattedSearchTerm = searchTerm ? searchTerm.toLowerCase() : '';
            const filtered = data.filter(admin => {
                const formattedCreatedDate = dayjs(admin.createdAt).format('DD-MM-YYYY').toLowerCase();
                const status = getStatus(admin.is_frozen, admin.role);
                return (
                    (!formattedSearchTerm ||
                        admin.username.toLowerCase().includes(formattedSearchTerm) ||
                        admin.name.toLowerCase().includes(formattedSearchTerm) ||
                        admin.email.toLowerCase().includes(formattedSearchTerm) ||
                        formattedCreatedDate.includes(formattedSearchTerm)
                    ) &&
                    (!statusFilter || admin.role.toString() === statusFilter)
                );
            });
            setFilteredData(filtered);
        };

        filterData();
    }, [data, searchTerm, statusFilter]);

    const handleCreateAdmin = () => {
        navigate('/AdminCreation');
    };
     const handleDeleteList = () => {
         navigate('/DeletedAdminList');
     };

    const sortedData = useMemo(() => {
        return sortData(filteredData, order, orderBy);
    }, [filteredData, order, orderBy, sortData]);

    const visibleRows = sortedData.slice(page * rowsPerPage, page * rowsPerPage + rowsPerPage);
    const numSelected = selected.length;
    const rowCount = filteredData.length;

    const handleFreeze = async (id, orgId, isFrozen) => {
        try {
            const confirmMsg = isFrozen ? "Resume" : "Freeze";
            if (!window.confirm(`Are you sure you want to ${confirmMsg} this admin?`)) return;
            setIsLoading(true);

            // Call the appropriate API endpoint based on the current status
            const response = isFrozen
                ? await apiServices.resumeEmployee(orgId, id) // Replace with your API endpoint
                : await apiServices.freezeEmployee(orgId, id); // Replace with your API endpoint

            if (response && !response.error) {
                // Update the local state to reflect the change in status
                setData(prevData =>
                    prevData.map(admin => {
                        if (admin.id === id) {
                            return { ...admin, is_frozen: !isFrozen };
                        } else {
                            return admin;
                        }
                    })
                );
                setFilteredData(prevData =>
                    prevData.map(admin => {
                        if (admin.id === id) {
                            return { ...admin, is_frozen: !isFrozen };
                        } else {
                            return admin;
                        }
                    })
                );
            }
        } catch (error) {
            console.error("Error freezing/resuming admin:", error);
        } finally {
            setIsLoading(false);
        }
    };

    return (
        <Box sx={{
            marginLeft: {
                xs: "0",
                sm: "0",
                md: "250px",
            },
            marginTop: "80px",
            width: {
                xs: '100%',
                sm: '100%',
                md: 'calc(100% - 250px)',
            },
            transition: 'width 0.3s ease-in-out',
            pr: 3,
            boxSizing: 'border-box'
        }}>
            {adminId && selectedAdmin ? (
                // Render details for a single admin
                <div>
                    <h2>Admin Details</h2>
                    <p>ID: {selectedAdmin.id}</p>
                    <p>Username: {selectedAdmin.username}</p>
                    <p>Name: {selectedAdmin.name}</p>
                    <p>Email: {selectedAdmin.email}</p>
                    {/* Display other admin details here */}
                </div>
            ) : (
                // Render the list of admins
                <div>
                    <Typography variant="h4" gutterBottom sx={{ fontWeight: 'bold', paddingRight: '20px', fontSize: '18px', color: '#000b58' }}>
                        Admin List
                    </Typography>
                    <Box sx={{
                        display: 'flex',
                        justifyContent: 'flex-end',
                        mb: 2,
                    }}>
                        <Button
                            variant="contained"
                            sx={{
                                backgroundColor: 'black',
                                color: 'white',
                                fontSize: '12px',
                                borderRadius: '7px',
                                padding: '4px 8px',
                                marginTop: '-40px',
                                mr: 1, // Add some right margin for spacing
                                '&:hover': {
                                    backgroundColor: '#424242',
                                },
                            }}
                            onClick={handleCreateAdmin}
                            startIcon={<AddIcon />}
                        >
                            New Admin
                        </Button>
                        <Button
                            variant="contained"
                            sx={{
                                backgroundColor: 'black',
                                color: 'white',
                                fontSize: '12px',
                                borderRadius: '7px',
                                padding: '4px 8px',
                                marginTop: '-40px',
                                '&:hover': {
                                    backgroundColor: '#424242',
                                },
                            }}
                            onClick={handleDeleteList}
                        >
                            Deleted List
                        </Button>
                    </Box>
                    <Card sx={{
                        width: '100%',
                        minWidth: 600,
                        padding: '1%',
                        backgroundColor: theme.palette.background.paper,
                        boxShadow: '0px 3px 5px rgba(0, 0, 0, 0.1)',
                        borderRadius: '8px',
                        border: `1px solid ${theme.palette.divider}`,
                        background: theme.palette.grey[50],
                        mx: 'auto',
                        boxSizing: 'border-box'
                    }}>
                        <Box display="flex" justifyContent="space-between" mb={2}>
                            <OutlinedInput
                                value={searchTerm}
                                onChange={handleSearch}
                                placeholder="Search..."
                                sx={{
                                    maxWidth: 260, fontSize: '14px',
                                    '&:hover .MuiOutlinedInput-notchedOutline': {
                                        borderColor: theme.palette.primary.main,
                                    },
                                    background: theme.palette.common.white,
                                }}
                                startAdornment={
                                    <InputAdornment position="start">
                                        <SearchIcon />
                                    </InputAdornment>
                                }
                                endAdornment={
                                    <InputAdornment position="end">
                                        <IconButton onClick={handleCalendarClick}>
                                            <CalendarMonthIcon />
                                        </IconButton>
                                    </InputAdornment>
                                }
                            />
                            <FormControl variant="outlined" sx={{ minWidth: 250 }}>
                                <InputLabel id="status-label" sx={{ fontSize: '12px' }}>Role</InputLabel>
                                <Select
                                    labelId="status-label"
                                    value={statusFilter}
                                    onChange={handleStatusFilter}
                                    label="Role"
                                    sx={{
                                        fontSize: '14px',
                                        '& .MuiSelect-select': { textDecoration: 'none' },
                                        background: theme.palette.common.white,
                                    }}
                                >
                                    <MenuItem value="" sx={{ fontSize: '12px' }}>All</MenuItem>
                                    <MenuItem value="PRODUCT_ADMIN" sx={{ fontSize: '12px' }}>PRODUCT_ADMIN</MenuItem>
                                    {/* Add more roles as needed */}
                                </Select>
                            </FormControl>
                        </Box>
                        <Popover
                            id={id}
                            open={open}
                            anchorEl={anchorEl}
                            onClose={handleClose}
                            anchorOrigin={{
                                vertical: 'bottom',
                                horizontal: 'left',
                            }}
                        >
                            <LocalizationProvider dateAdapter={AdapterDayjs} adapterLocale="en">
                                <DatePicker
                                    value={selectedDate}
                                    onChange={handleDateChange}
                                    renderInput={() => { }}
                                    format="DD-MM-YYYY"
                                />
                            </LocalizationProvider>
                        </Popover>
                        <TableContainer sx={{ width: '100%', maxHeight: '350px', overflowY: 'auto' }}>
                            <Table size="small" sx={{ width: '100%', minWidth: 650 }}>
                                <UserTableHead
                                    order={order}
                                    orderBy={orderBy}
                                    onRequestSort={handleSort}
                                    onSelectAllClick={handleSelectAllClick}
                                    numSelected={numSelected}
                                    rowCount={rowCount}
                                />
                                <TableBody>
                                    {visibleRows.map(row => {
                                        const isItemSelected = isSelected(row.id);
                                        return (
                                            <UserTableRow
                                                key={row.id}
                                                row={row}
                                                handleEdit={handleEdit}
                                                handleDelete={handleDelete}
                                                isSelected={isItemSelected}
                                                handleClick={handleClick}
                                                handleFreeze={handleFreeze}
                                            />
                                        );
                                    })}
                                    {filteredData.length === 0 && (
                                        <TableRow>
                                            <TableCell colSpan={8} align="center" sx={{ fontSize: '12px' }}>No results found.</TableCell>
                                        </TableRow>
                                    )}
                                </TableBody>
                            </Table>
                        </TableContainer>
                        <TablePagination
                            rowsPerPageOptions={[5, 10, 25]}
                            count={filteredData.length}
                            rowsPerPage={rowsPerPage}
                            page={page}
                            onPageChange={handleChangePage}
                            onRowsPerPageChange={handleChangeRowsPerPage}
                            labelRowsPerPage="Rows per page:"
                            sx={{
                                display: 'flex',
                                justifyContent: 'flex-end',
                                alignItems: 'center',
                                fontSize: '12px',
                                background: theme.palette.common.white,
                                border: 'none',
                            }}
                            labelDisplayedRows={({ from, to, count }) => `${from}-${to} of ${count}`}
                        />
                    </Card>
                </div>
            )}
            {isLoading && (
                <div className="loading-popup">
                    <div className="loading-popup-content">
                        <Loader type="box-up" bgColor={'#000b58'} color={'#000b58'} size={100} />
                        <p>Loading...</p>
                    </div>
                </div>
            )}
        </Box>
    );
};

export default AdminList;
