import React, { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { TextField, MenuItem, Button, CircularProgress, Box, Container, Paper, Grid } from "@mui/material";
import apiServices from '../../ApiServices/ApiServices';
import Loader from "react-js-loader";
import "./CreateUser.css"; // Make sure this CSS uses relative units!

const CreateUser = () => {
  const [formData, setFormData] = useState({
    username: '',
    companyname: localStorage.getItem('Company_name') || '',
    firstName: '',
    lastName: '',
    mobile: '',
    email: '',
    created_at: '',
    role: ''
  });
  const [message, setMessage] = useState('');
  const navigate = useNavigate();
  const [isLoading, setIsLoading] = useState(false);

  const roleOptions = ["Compiler", "Approver", "Viewer"];

  const handleChange = (e) => {
    const { name, value } = e.target;
    setFormData({
      ...formData,
      [name]: value
    });
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    setIsLoading(true);
    try {
      await apiServices.register(formData);
      setMessage('User registered successfully!');
      navigate('/user-list');
    } catch (error) {
      const errorMessage = error.response?.data?.error || error.error;
      setMessage(`Error: ${errorMessage}`);
      setTimeout(() => setMessage(''), 3000);
    } finally {
      setIsLoading(false);
    }
  };

  const handleCancel = () => {
    navigate("/AdminList");
  };

  return (
    <Container
      sx={{
        display: 'flex',
        justifyContent: 'center',
        alignItems: 'center',
        width: '85%',
        //padding: '16px',
        marginTop: '20px',
        marginLeft: '180px', // Adjust this value based on the width of your aside bar
      }}
    >
      <Paper
        elevation={0} //  Modified line
        className="usercreation-container"
        style={{
          width: '100%',
          maxWidth: '1000px', // Increased maxWidth
          padding: '16px',
        }}

      >
        <h2 className="usercreation-title" style={{}}>Access Creation</h2>
        {message && (
          <Box sx={{ backgroundColor: 'red', color: 'white', padding: '8px', marginBottom: '16px' }} role="alert">
            {message}
          </Box>
        )}
        <form onSubmit={handleSubmit}>
          <Grid container spacing={2}>
            <Grid item xs={12} sm={6}>
              <TextField
                label="First Name"
                name="firstName"
                value={formData.firstName}
                onChange={handleChange}
                required
                fullWidth
                variant="outlined"
                size="small"
              />
            </Grid>
            <Grid item xs={12} sm={6}>
              <TextField
                label="Last Name"
                name="lastName"
                value={formData.lastName}
                onChange={handleChange}
                required
                fullWidth
                variant="outlined"
                size="small"
              />
            </Grid>
            <Grid item xs={12}>
              <TextField
                fullWidth
                label="Username"
                name="username"
                value={formData.username}
                onChange={handleChange}
                required
                size="small"
                variant="outlined"
              />
            </Grid>
            <Grid item xs={12}>
              <TextField
                fullWidth
                label="Company Name"
                name="companyname"
                value={formData.companyname}
                onChange={handleChange}
                required
                size="small"
                InputProps={{ readOnly: true }}
                variant="outlined"
              />
            </Grid>
            <Grid item xs={12}>
              <TextField
                fullWidth
                label="Mail ID"
                name="email"
                type="email"
                value={formData.email}
                onChange={handleChange}
                required
                size="small"
                variant="outlined"
              />
            </Grid>
            <Grid item xs={12}>
              <Box sx={{ display: "flex", gap: 2, alignItems: "center" }}>
                <TextField
                  select
                  label="Code"
                  name="countryCode"
                  value={formData.countryCode}
                  onChange={handleChange}
                  variant="outlined"
                  sx={{ width: "120px" }}
                  size="small"
                >
                  <MenuItem value="+1">+1</MenuItem>
                  <MenuItem value="+91">+91</MenuItem>
                  <MenuItem value="+44">+44</MenuItem>
                </TextField>
                <TextField
                  label="Contact Number"
                  type="tel"
                  name="contactNumber"
                  value={formData.contactNumber}
                  onChange={handleChange}
                  required
                  fullWidth
                  variant="outlined"
                  size="small"
                />
              </Box>
            </Grid>
            <Grid item xs={12}>
              <TextField
                fullWidth
                label="Access Creation Date"
                name="created_at"
                type="date"
                value={formData.created_at}
                onChange={handleChange}
                required
                size="small"
                InputLabelProps={{ shrink: true }}
                variant="outlined"
              />
            </Grid>
            <Grid item xs={12}>
              <TextField
                fullWidth
                select
                label="Role"
                name="role"
                value={formData.role}
                onChange={handleChange}
                required
                size="small"
                variant="outlined"
              >
                {roleOptions.map((option) => (
                  <MenuItem key={option} value={option}>{option}</MenuItem>
                ))}
              </TextField>
            </Grid>
          </Grid>
          <Box className="usercreation-button-group" sx={{ mt: 3, gap: 2, display: 'flex', justifyContent: 'flex-end' }}>
            <Button className='cancel-button' variant="outlined" color="secondary" onClick={handleCancel}>
              Cancel
            </Button>
            <Button variant="contained" color="primary" type="submit" disabled={isLoading}>
              {isLoading ? <CircularProgress size={24} /> : "Create"}
            </Button>
          </Box>
        </form>
        {isLoading && (
          <Box className="usercreation-loading-popup">
            <Box className="usercreation-loading-popup-content">
              <Loader type="box-up" bgColor={'#000b58'} color={'#000b58'} size={100} />
              <p>Loading...</p>
            </Box>
          </Box>
        )}
      </Paper>
    </Container>
  );
};

export default CreateUser;