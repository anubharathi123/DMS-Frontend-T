/* eslint-disable no-const-assign */
import React, { useState, useRef, useEffect, useCallback, useMemo } from 'react';
import { useNavigate } from 'react-router-dom';
import DatePicker from 'react-datepicker';
import 'react-datepicker/dist/react-datepicker.css';
import apiServices from '../../ApiServices/ApiServices';
import {
    Box, Card, Table, Button, TableBody, Typography, TableContainer,
    TablePagination, TableRow, TableCell, TableHead, Select, MenuItem,
    FormControl, InputLabel, TableSortLabel, Tooltip, OutlinedInput, InputAdornment,
    IconButton, Menu, ListItemIcon, ListItemText, useTheme, useMediaQuery, Popover, Checkbox
} from '@mui/material';
import SearchIcon from '@mui/icons-material/Search';
import 'react-datepicker/dist/react-datepicker.css';
import './OrganizationList.css';
import Loader from "react-js-loader";
import { IoMdInformationCircleOutline } from "react-icons/io";
import refreshIcon from '../../assets/images/refresh-icon.png';
import dayjs from 'dayjs';
import { AdapterDayjs } from '@mui/x-date-pickers/AdapterDayjs';
import { LocalizationProvider } from '@mui/x-date-pickers/LocalizationProvider';
import CalendarMonthIcon from '@mui/icons-material/CalendarMonth';

const headLabel = [
    { id: 'select', label: '', align: 'center', width: '5%' },
    { id: 'username', label: 'Username', align: 'left', width: '25%' },
    { id: 'org_name', label: 'Organization Name', align: 'left', width: '40%' },
    { id: 'msa_doc', label: 'MSA Document', align: 'left', width: '20%' },
    { id: 'created_date', label: 'Created Date', align: 'left', width: '10%' },
];

const UserTableHead = ({ order, orderBy, onRequestSort }) => {
    const createSortHandler = (property) => (event) => {
        onRequestSort(event, property);
    };
    const theme = useTheme();
    return (
        <TableHead sx={{
            background: theme.palette.grey[100],
            borderBottom: `1px solid ${theme.palette.divider}`,
        }}>
            <TableRow>
                {headLabel.map((headCell) => (
                    <TableCell
                        key={headCell.id}
                        align={headCell.align}
                        sx={{
                            fontWeight: '600',
                            padding: '16px 12px', // Adjusted padding for more spacing
                            whiteSpace: 'nowrap',
                            width: headCell.width,
                            color: theme.palette.text.primary,
                            fontSize: '14px',
                            '& .MuiTableSortLabel-root': {
                                color: theme.palette.text.primary,
                                '&:hover': {
                                    color: theme.palette.primary.main,
                                },
                                '&.Mui-active': {
                                    color: theme.palette.primary.main,
                                },
                            },
                        }}
                    >
                        {headCell.id === 'select' ? (
                            <Checkbox
                                size="small"
                                inputProps={{ 'aria-label': 'select all organizations' }}
                            />
                        ) : (
                            <TableSortLabel
                                active={orderBy === headCell.id}
                                direction={orderBy === headCell.id ? order : 'asc'}
                                onClick={createSortHandler(headCell.id)}
                            >
                                {headCell.label}
                            </TableSortLabel>
                        )}
                    </TableCell>
                ))}
            </TableRow>
        </TableHead>
    );
};

const OrganizationList = () => {
    const [data, setData] = useState([]);
    const [searchTerm, setSearchTerm] = useState('');
    const [order, setOrder] = useState('asc');
    const [orderBy, setOrderBy] = useState('username');
    const [page, setPage] = useState(0);
    const [rowsPerPage, setRowsPerPage] = useState(5);
    const theme = useTheme();
    const navigate = useNavigate();
    const [selectedDate, setSelectedDate] = useState(null);
    const [isLoading, setIsLoading] = useState(false);
    const [filteredData, setFilteredData] = useState([]);
    const [selectedOrgs, setSelectedOrgs] = useState([]);
    const [isCalendarOpen, setIsCalendarOpen] = useState(false); // State to control calendar visibility
    const calendarRef = useRef(null);
    const url = "http://localhost:8000";

    useEffect(() => {
        const fetchOrganization = async () => {
            try {
                setIsLoading(true);
                const response = await apiServices.getOrganizations();
                const organization = response.organization.map(org => ({
                    id: org.id,
                    username: org.auth_user.username,
                    org_name: org.company_name,
                    msa_doc: org.contract_doc,
                    created_date: org.created_at,
                    delete: org.is_delete,
                }));
                const filterdata = organization.filter(org => org.delete === true)
                setData(filterdata);
                setFilteredData(filterdata);
                if (organization.length === 0) {
                    // setActionMessage("No Organizations are found in the list.");
                }
            } catch (error) {
                console.error(error);
            } finally {
                setIsLoading(false);
            }
        };

        fetchOrganization();
    }, [navigate]);

    const handleSearch = (e) => {
        setSearchTerm(e.target.value.toLowerCase());
        setPage(0);
        setSelectedDate(null);
    };

    const handleSort = (event, property) => {
        const isAsc = orderBy === property && order === 'asc';
        setOrder(isAsc ? 'desc' : 'asc');
        setOrderBy(property);
    };

    const handleChangePage = (event, newPage) => {
        setPage(newPage);
    };

    const handleChangeRowsPerPage = (event) => {
        setRowsPerPage(parseInt(event.target.value, 10));
        setPage(0);
    };

    const handleDateChange = (date) => {
        const formattedDate = date ? dayjs(date).format('DD-MM-YYYY') : '';
        setSelectedDate(date);
        setSearchTerm(formattedDate.toLowerCase());
        setPage(0);
        setIsCalendarOpen(false); // Close the calendar after date selection
    };

    const sortData = useCallback((dataToSort, order, orderBy) => {
        return [...dataToSort].sort((a, b) => {
            let comparison = 0;
            if (orderBy === 'username') {
                comparison = a.username.localeCompare(b.username);
            } else if (orderBy === 'org_name') {
                comparison = a.org_name.localeCompare(b.org_name);
            } else if (orderBy === 'msa_doc') {
                comparison = a.msa_doc.localeCompare(b.msa_doc);
            } else if (orderBy === 'created_date') {
                comparison = new Date(a.created_date).getTime() - new Date(b.created_date).getTime();
            }

            return order === 'asc' ? comparison : -comparison;
        });
    }, []);

    useEffect(() => {
        const filterData = () => {
            const formattedSearchTerm = searchTerm ? searchTerm.toLowerCase() : '';
            const filtered = data.filter(org => {
                const formattedCreatedDate = selectedDate ? dayjs(org.created_date).format('DD-MM-YYYY').toLowerCase() : '';

                return (
                    (!formattedSearchTerm ||
                        org.username.toLowerCase().includes(formattedSearchTerm) ||
                        org.org_name.toLowerCase().includes(formattedSearchTerm) ||
                        (selectedDate && formattedCreatedDate.includes(formattedSearchTerm))
                    )
                );
            });
            setFilteredData(filtered);
        };

        filterData();
    }, [data, searchTerm, selectedDate]);

    const sortedData = useMemo(() => {
        return sortData(filteredData, order, orderBy);
    }, [filteredData, order, orderBy, sortData]);

    const visibleRows = sortedData.slice(page * rowsPerPage, page * rowsPerPage + rowsPerPage);

    const handleSelectOrg = (event, id) => {
        const selectedIndex = selectedOrgs.indexOf(id);
        let newSelected = [];

        if (selectedIndex === -1) {
            newSelected = newSelected.concat(selectedOrgs, id);
        } else if (selectedIndex === 0) {
            newSelected = newSelected.concat(selectedOrgs.slice(1));
        } else if (selectedIndex === selectedOrgs.length - 1) {
            newSelected = newSelected.concat(selectedOrgs.slice(0, -1));
        } else if (selectedIndex > 0) {
            newSelected = newSelected.concat(
                selectedOrgs.slice(0, selectedIndex),
                selectedOrgs.slice(selectedIndex + 1),
            );
        }

        setSelectedOrgs(newSelected);
    };

    const isOrgSelected = (id) => selectedOrgs.indexOf(id) !== -1;

    const handleCalendarClick = () => {
        setIsCalendarOpen(!isCalendarOpen); // Toggle calendar visibility
    };

    useEffect(() => {
        const handleClickOutside = (event) => {
            if (calendarRef.current && !calendarRef.current.contains(event.target)) {
                setIsCalendarOpen(false);
            }
        };

        document.addEventListener("mousedown", handleClickOutside);
        return () => {
            document.removeEventListener("mousedown", handleClickOutside);
        };
    }, [calendarRef]);


    return (
        <Box sx={{
            marginLeft: {
                xs: "0",
                sm: "0",
                md: "250px",
            },
            marginTop: "80px",
            width: {
                xs: '100%',
                sm: '100%',
                md: 'calc(100% - 250px)',
            },
            transition: 'width 0.3s ease-in-out',
            pr: 3,
            boxSizing: 'border-box'
        }}>
            <Typography variant="h4" gutterBottom sx={{ fontWeight: 'bold', paddingRight: '20px', fontSize: '18px', color: '#000b58' }}>
                Organization Details
            </Typography>
            <Card sx={{
                width: '100%',
                minWidth: 600,
                padding: '1%',
                backgroundColor: theme.palette.background.paper,
                boxShadow: '0px 3px 5px rgba(0, 0, 0, 0.1)',
                borderRadius: '8px',
                border: `1px solid ${theme.palette.divider}`,
                background: theme.palette.grey[50],
                mx: 'auto',
                boxSizing: 'border-box'
            }}>
                <Box display="flex" justifyContent="space-between" alignItems="center" mb={2}>
                    <OutlinedInput
                        value={searchTerm}
                        onChange={handleSearch}
                        placeholder="Search..."
                        sx={{
                            maxWidth: 260, fontSize: '14px',
                            '&:hover .MuiOutlinedInput-notchedOutline': {
                                borderColor: theme.palette.primary.main,
                            },
                            background: theme.palette.common.white,
                        }}
                        startAdornment={
                            <InputAdornment position="start">
                                <SearchIcon />
                            </InputAdornment>
                        }
                        endAdornment={
                            <InputAdornment position="end">
                                <IconButton onClick={handleCalendarClick}>
                                    <CalendarMonthIcon />
                                </IconButton>
                            </InputAdornment>
                        }
                    />

                </Box>
                {isCalendarOpen && (
                    <div ref={calendarRef} style={{ position: 'absolute', zIndex: 1, backgroundColor: 'white', boxShadow: '0px 4px 8px rgba(0,0,0,0.2)' }}>
                        <LocalizationProvider dateAdapter={AdapterDayjs} adapterLocale="en">
                            <DatePicker
                                selected={selectedDate}
                                onChange={handleDateChange}
                                dateFormat="dd-MM-yyyy"
                                inline // Display the calendar inline
                            />
                        </LocalizationProvider>
                    </div>
                )}

                <TableContainer sx={{ width: '100%', maxHeight: '350px', overflowY: 'auto' }}>
                    <Table size="small" sx={{ width: '100%', minWidth: 650 }}>
                        <UserTableHead
                            order={order}
                            orderBy={orderBy}
                            onRequestSort={handleSort}
                        />
                        <TableBody>
                            {visibleRows.map(org => {
                                const isSelected = isOrgSelected(org.id);
                                return (
                                    <TableRow
                                        hover
                                        key={org.id}
                                        sx={{
                                            '&:nth-of-type(odd)': {
                                                backgroundColor: theme.palette.grey[50],
                                            },
                                            '&:hover': {
                                                backgroundColor: theme.palette.grey[100],
                                            },
                                            '&.Mui-selected': {
                                                backgroundColor: theme.palette.grey[200],
                                            },
                                        }}
                                        selected={isSelected}
                                    >
                                        <TableCell padding="checkbox" align="center">
                                            <Checkbox
                                                size="small"
                                                checked={isSelected}
                                                onChange={(event) => handleSelectOrg(event, org.id)}
                                                inputProps={{ 'aria-labelledby': `select-org-${org.id}` }}
                                            />
                                        </TableCell>
                                        <TableCell sx={{ padding: '16px 12px', whiteSpace: 'nowrap', color: theme.palette.text.primary, fontSize: '14px' }} id={`select-org-${org.id}`}>{org.username}</TableCell>
                                        <TableCell sx={{ padding: '16px 12px', whiteSpace: 'nowrap', color: theme.palette.text.primary, fontSize: '14px' }}>
                                            <Tooltip title={org.org_name} arrow>
                                                <span>{org.org_name.length > 20 ? `${org.org_name.substring(0, 20)}...` : org.org_name}</span>
                                            </Tooltip>
                                        </TableCell>
                                        <TableCell sx={{ padding: '16px 12px', whiteSpace: 'nowrap', color: theme.palette.text.primary, fontSize: '14px' }}>
                                            {org.msa_doc ? (
                                                <a href={(url + org.msa_doc)}
                                                    title={org.msa_doc.split('/').pop()}
                                                    target='_blank' rel='noopener noreferrer'>
                                                    {org.msa_doc.split('/').pop().substring(0, 30) + '...'}
                                                </a>
                                            ) : (
                                                "Null"
                                            )}
                                        </TableCell>
                                        <TableCell sx={{ padding: '16px 12px', whiteSpace: 'nowrap', color: theme.palette.text.primary, fontSize: '14px' }}>{new Date(org.created_date).toLocaleDateString()}</TableCell>
                                    </TableRow>
                                );
                            })}
                            {filteredData.length === 0 && (
                                <TableRow>
                                    <TableCell colSpan={headLabel.length} align="center" sx={{ fontSize: '14px' }}>No results found.</TableCell>
                                </TableRow>
                            )}
                        </TableBody>
                    </Table>
                </TableContainer>
                <TablePagination
                    rowsPerPageOptions={[5, 10, 25]}
                    component="div"
                    count={filteredData.length}
                    rowsPerPage={rowsPerPage}
                    page={page}
                    onPageChange={handleChangePage}
                    onRowsPerPageChange={handleChangeRowsPerPage}
                    labelRowsPerPage="Rows per page:"
                    sx={{
                        display: 'flex',
                        justifyContent: 'flex-end',
                        alignItems: 'center',
                        fontSize: '14px',
                        background: theme.palette.common.white,
                        border: 'none',
                    }}
                    labelDisplayedRows={({ from, to, count }) => `${from}-${to} of ${count}`}
                />
            </Card>
            {isLoading && (
                <div className="loading-popup">
                    <div className="loading-popup-content">
                        <Loader type="box-up" bgColor={'#000b58'} color={'#000b58'} size={100} />
                        <p>Loading...</p>
                    </div>
                </div>
            )}
        </Box>
    );
};

export default OrganizationList;
